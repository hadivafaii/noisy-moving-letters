"""Texture carriers, their temporal processes, and the map from latent values to pixel values.

A carrier is a random texture attached to a layer's own coordinates, so it moves with
the layer. The dense carrier is a field of standard-normal texels; the dot carrier is a
set of dots. Temporal coherence decides how much of the texture survives each frame.
"""

import numpy as np
from nml.limits import check_allocation
from scipy import ndimage, special


def carried_field(shape, frames, coherence, mode, rng_base, rng_dyn, blur=0.0) -> np.ndarray:
	"""Standard-normal texel field (frames, h, w) whose temporal correlation is set by `coherence`.

	refresh: each texel is resampled with probability 1 - coherence per frame (geometric lifetimes).
	lifetime: each texel lives 1 / (1 - coherence) frames, with a random initial phase.
	ar1: z <- coherence * z + sqrt(1 - coherence²) * fresh.
	The base texture and the refresh draws come from separate generators, so clips that differ
	only in coherence share their first frame, and lower coherence refreshes a superset of texels.
	"""
	pad = int(np.ceil(4 * blur)) if blur > 0 else 0
	h, w = shape[0] + 2 * pad, shape[1] + 2 * pad
	z = np.empty((1 if coherence >= 1 else frames, h, w), dtype=np.float32)
	z[0] = rng_base.standard_normal((h, w))
	if coherence >= 1:
		z[1:] = z[0]
	elif mode == "refresh":
		for t in range(1, frames):
			refresh = rng_dyn.random((h, w)) < 1 - coherence
			z[t] = np.where(refresh, rng_dyn.standard_normal((h, w)), z[t - 1])
	elif mode == "lifetime":
		life = max(1, int(round(1 / (1 - coherence))))
		phase = rng_dyn.integers(0, life, (h, w))
		for t in range(1, frames):
			z[t] = np.where((t + phase) % life == 0, rng_dyn.standard_normal((h, w)), z[t - 1])
	elif mode == "ar1":
		noise_scale = np.sqrt(1 - coherence ** 2)
		for t in range(1, frames):
			z[t] = coherence * z[t - 1] + noise_scale * rng_dyn.standard_normal((h, w))
	else:
		raise ValueError(f"Unknown coherence mode {mode!r}")
	if blur > 0:
		impulse = np.zeros(8 * pad + 1)
		impulse[4 * pad] = 1.0
		kernel = ndimage.gaussian_filter1d(impulse, blur)
		z = ndimage.gaussian_filter(z, (0, blur, blur), mode="nearest") / np.sum(kernel ** 2)
		z = z[:, pad:h - pad, pad:w - pad]
	return np.broadcast_to(z, (frames, *z.shape[1:])) if coherence >= 1 else z


def gather_pixel_texture(tx, ty, owned, grain, blur, coherence, mode, rng_base, rng_dyn, out):
	"""Write the carried texture sampled at texture coordinates (tx, ty) into `out` where `owned`."""
	if not owned.any():
		return
	# Bounding and sampling frame by frame avoid full-video integer index arrays.
	# Keep the carried field and RNG draws identical to the vectorized operation.
	x0 = y0 = np.inf
	x1 = y1 = -np.inf
	for t, mine in enumerate(owned):
		if mine.any():
			ix, iy = np.floor(tx[t][mine] / grain), np.floor(ty[t][mine] / grain)
			x0, x1 = min(x0, ix.min()), max(x1, ix.max())
			y0, y1 = min(y0, iy.min()), max(y1, iy.max())
	x0, y0 = int(x0), int(y0)
	shape = (int(y1) - y0 + 1, int(x1) - x0 + 1)
	check_allocation(shape[0] * shape[1] * (1 if coherence >= 1 else tx.shape[0]), "Texture field")
	field = carried_field(shape, tx.shape[0], coherence, mode, rng_base, rng_dyn, blur)
	for t, mine in enumerate(owned):
		ix = np.floor(tx[t][mine] / grain).astype(np.int64)
		iy = np.floor(ty[t][mine] / grain).astype(np.int64)
		out[t][mine] = field[t, iy - y0, ix - x0]


def to_pixels(u, texture) -> np.ndarray:
	"""Map latent values (standard normal under pure noise) to pixel values with the configured marginal."""
	m = texture.marginal
	if m == "binary":
		return np.where(u > special.ndtri(1 - texture.p_on), texture.hi, texture.lo).astype(np.float32)
	if m == "gaussian":
		return np.clip(0.5 + texture.spread * u, 0, 1).astype(np.float32)
	p = special.ndtr(u)
	if m == "uniform":
		x = texture.lo + (texture.hi - texture.lo) * p
	elif m == "levels":
		k = int(texture.levels)
		x = texture.lo + (texture.hi - texture.lo) * np.minimum(np.floor(p * k), k - 1) / (k - 1)
	elif m == "laplace":
		x = np.clip(0.5 - texture.spread * np.sign(p - 0.5) * np.log1p(-2 * np.abs(p - 0.5)), 0, 1)
	else:
		raise ValueError(f"Unknown marginal {m!r}")
	return x.astype(np.float32)


def splat_dots(xy, amp, diameter, height, width) -> np.ndarray:
	"""Anti-aliased disks of the given amplitudes, summed and clipped to [-1, 1]."""
	img = np.zeros((height, width), dtype=np.float32)
	if len(xy) == 0:
		return img
	r = diameter / 2
	k = int(np.ceil(r)) + 1
	check_allocation(len(xy) * (2 * k + 1) ** 2 * 8, "Dot rendering")
	off = np.arange(-k, k + 1)
	ox, oy = np.meshgrid(off, off)
	px = np.floor(xy[:, 0])[:, None] + ox.ravel()
	py = np.floor(xy[:, 1])[:, None] + oy.ravel()
	cover = np.clip(r + 0.5 - np.hypot(px + 0.5 - xy[:, :1], py + 0.5 - xy[:, 1:]), 0, 1)
	keep = (cover > 0) & (px >= 0) & (px < width) & (py >= 0) & (py < height)
	np.add.at(img, (py[keep].astype(int), px[keep].astype(int)), (cover * amp[:, None])[keep])
	return np.clip(img, -1, 1)


class DotLayer:
	"""Dots of one layer, in that layer's coordinates.

	Object layers keep their dots inside the shape (respawning any that leave it) and add or
	remove dots so that the on-screen density stays fixed as the object scales. World layers
	(the background, or a figure in window mode) cover the frame and wrap around its edges,
	re-drawing the coordinate that did not wrap so no pattern repeats.
	"""

	def __init__(self, rng, density, polarity, coherence, mode, coherent_fraction, shape=None, frame=None):
		self.rng, self.density, self.polarity = rng, density, polarity
		self.refresh = 1 - coherence
		self.life = max(1, int(round(1 / self.refresh))) if 0 < self.refresh else None
		self.mode, self.coherent_fraction = mode, coherent_fraction
		self.shape, self.frame = shape, frame
		self.area = shape.area() if shape is not None else frame[0] * frame[1]
		self.pos = np.zeros((0, 2))
		self.age = np.zeros(0, dtype=int)
		self.coherent = np.zeros(0, dtype=bool)
		self.heading = np.zeros((0, 2))
		self.amp = np.zeros(0)

	def _new(self, n):
		check_allocation(n * 128, "Dot population")
		rng = self.rng
		if self.shape is None:
			pos = rng.random((n, 2)) * self.frame
		else:
			pos = np.zeros((0, 2))
			r = self.shape.radius
			while len(pos) < n:
				cand = (rng.random((max(4 * (n - len(pos)), 16), 2)) * 2 - 1) * r
				pos = np.vstack([pos, cand[self.shape.sdf(cand[:, 0], cand[:, 1]) < 0]])
			pos = pos[:n]
		theta = rng.random(n) * 2 * np.pi
		amp = {"white": np.ones(n), "black": -np.ones(n)}.get(self.polarity)
		if amp is None:
			amp = np.where(rng.random(n) < 0.5, 1.0, -1.0)
		age = rng.integers(0, self.life, n) if self.mode == "lifetime" and self.life else np.zeros(n, dtype=int)
		return pos, age, rng.random(n) < self.coherent_fraction, np.stack([np.cos(theta), np.sin(theta)], 1), amp

	def _replace(self, idx):
		new = self._new(len(idx))
		for name, value in zip(("pos", "age", "coherent", "heading", "amp"), new):
			getattr(self, name)[idx] = value
		self.age[idx] = 0

	def _resize(self, n):
		if n > len(self.pos):
			new = self._new(n - len(self.pos))
			for name, value in zip(("pos", "age", "coherent", "heading", "amp"), new):
				setattr(self, name, np.concatenate([getattr(self, name), value]))
		elif n < len(self.pos):
			keep = np.sort(self.rng.permutation(len(self.pos))[:n])
			for name in ("pos", "age", "coherent", "heading", "amp"):
				setattr(self, name, getattr(self, name)[keep])

	def step(self, shift, random_step, target_scale=1.0, first=False, carry=(0.0, 0.0)):
		"""Advance one frame. `shift` moves coherent dots (in layer coordinates); incoherent dots move by
		`random_step` along their own heading instead. `carry` then moves every dot, e.g. against the eye's
		motion. Returns positions in layer coordinates."""
		n = int(round(self.density * self.area * target_scale ** 2))
		if first:
			self._resize(n)
			return self.pos
		self.age += 1
		self.pos = self.pos + np.where(self.coherent[:, None], shift, self.heading * random_step) + np.asarray(carry)
		if self.mode == "lifetime":
			dead = self.age >= self.life if self.life else np.zeros(len(self.pos), dtype=bool)
		else:
			dead = self.rng.random(len(self.pos)) < self.refresh
		if self.shape is None:
			size = np.asarray(self.frame, dtype=float)
			out = (self.pos < 0) | (self.pos >= size)
			self.pos = np.mod(self.pos, size)
			redraw = self.rng.random(self.pos.shape) * size
			self.pos = np.where(out[:, ::-1] & ~out, redraw, self.pos)
		else:
			dead |= self.shape.sdf(self.pos[:, 0], self.pos[:, 1]) >= 0
		self._replace(np.nonzero(dead)[0])
		self._resize(n)
		return self.pos
