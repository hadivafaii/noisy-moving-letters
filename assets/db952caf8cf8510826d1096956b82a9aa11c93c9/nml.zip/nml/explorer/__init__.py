"""Interactive stimulus explorer: side-by-side panels rendered live by the Python generator."""
