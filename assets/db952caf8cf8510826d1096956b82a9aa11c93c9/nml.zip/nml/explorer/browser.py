"""Pyodide transport for the original explorer API; no alternative simulator."""

import gc
import json
from pathlib import Path

import numpy as np

from nml.explorer.server import (
    DEFAULT_PREVIEW_BUDGET, PreviewLimitExceeded, api_request, export_frames,
    export_scale, validate_preview_budget,
)
from nml.limits import allocation_budget
from nml.viz import _export_image, to_uint8

DOWNLOAD = "/tmp/nml-browser-download"
MAX_EXPORT = 33_554_432


def dispatch(path, encoded_body):
    """Return response metadata; binary downloads use the worker's virtual FS."""
    token = allocation_budget.set(DEFAULT_PREVIEW_BUDGET)
    try:
        body = json.loads(encoded_body)
        ceiling = MAX_EXPORT if path == "/api/export" else DEFAULT_PREVIEW_BUDGET
        requested = validate_preview_budget(body.get("preview_budget", DEFAULT_PREVIEW_BUDGET))
        body["preview_budget"] = min(requested, ceiling)
        if path == "/api/export" and body.get("format") == "mp4":
            frames, fps, overlays, filename = export_frames(body, body["preview_budget"])
            frames = to_uint8(frames)
            scale = export_scale(body, frames.shape[2], frames.shape[1])
            with open(DOWNLOAD, "wb") as output:
                for frame in frames:
                    pixels = np.asarray(_export_image(frame, scale, overlays).convert("L"))
                    h, w = pixels.shape
                    if h % 2 or w % 2:
                        pixels = np.pad(pixels, ((0, h % 2), (0, w % 2)))
                    output.write(pixels.tobytes())
            return json.dumps({"status": 200, "raw_video": True, "file": DOWNLOAD,
                               "width": w + w % 2, "height": h + h % 2, "fps": fps,
                               "filename": filename + ".mp4", "content_type": "video/mp4"})
        reply = api_request(path, body)
        result = {"status": reply.status, "content_type": reply.content_type,
                  "filename": reply.filename}
        if reply.content_type == "application/json":
            result["body"] = reply.body
        else:
            Path(DOWNLOAD).write_bytes(reply.body)
            result["file"] = DOWNLOAD
        return json.dumps(result, allow_nan=False)
    except PreviewLimitExceeded as exc:
        return json.dumps({"status": 409, "body": {"error": str(exc), "code": "preview_limit",
                           "requested": exc.requested, "preview_budget": exc.budget,
                           "max_frames": exc.max_frames}})
    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        return json.dumps({"status": 400, "body": {"error": str(exc)}})
    finally:
        allocation_budget.reset(token)
        gc.collect()
