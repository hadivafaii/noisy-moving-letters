"""Alphabets and font glyphs as signed distance functions.

Adapted from fondv2/data_generators/captcha (alphabet.py, and the glyph renderer in generate.py).
"""

import functools
import string
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage


ALPHABET_PARTS = {
	"lower": string.ascii_lowercase,
	"lowercase": string.ascii_lowercase,
	"upper": string.ascii_uppercase,
	"uppercase": string.ascii_uppercase,
	"digits": string.digits,
	"numbers": string.digits,
	"alnum62": string.ascii_lowercase + string.ascii_uppercase + string.digits,
	"alphanumeric": string.ascii_lowercase + string.ascii_uppercase + string.digits,
}

# Glyph bitmaps are rendered once per (char, font) with this cap height, then sampled at any size.
_CAP_HEIGHT = 128
_PAD = 24


def build_alphabet(spec: str = "upper,digits") -> str:
	tokens = [token.strip() for token in str(spec).split(",") if token.strip()]
	if not tokens:
		raise ValueError("alphabet must include at least one token")

	chars = []
	seen = set()
	for token in tokens:
		if token in ALPHABET_PARTS:
			values = ALPHABET_PARTS[token]
		elif token.startswith("chars:"):
			values = token.removeprefix("chars:")
		else:
			raise ValueError(
				f"Unknown alphabet token {token!r}; choices are "
				f"{tuple(sorted(ALPHABET_PARTS))} or chars:<literal>"
			)
		for char in values:
			if char not in seen:
				seen.add(char)
				chars.append(char)

	if not chars:
		raise ValueError("alphabet resolved to no characters")
	return "".join(chars)


def resolve_chars(spec: str) -> str:
	"""An alphabet spec ("upper,digits"), or else the literal characters of `spec`."""
	try:
		return build_alphabet(spec)
	except ValueError:
		chars = "".join(dict.fromkeys(c for c in str(spec) if not c.isspace() and c != ","))
		if not chars:
			raise ValueError(f"No characters in {spec!r}")
		return chars


@functools.lru_cache(maxsize=None)
def find_font(font: str = "DejaVu Sans:bold") -> str:
	if Path(font).suffix.lower() in {".ttf", ".otf", ".ttc"}:
		return str(Path(font).expanduser())
	from matplotlib import font_manager

	family, _, weight = font.partition(":")
	props = font_manager.FontProperties(family=family, weight=weight or "normal")
	return font_manager.findfont(props, fallback_to_default=True)


@functools.lru_cache(maxsize=1)
def available_fonts() -> list[dict]:
	"""Installed upright fonts with Latin glyphs, using portable family/weight specs."""
	from matplotlib import font_manager, ft2font

	weights = {100: "Thin", 200: "Extra light", 300: "Light", 400: "Regular",
		500: "Medium", 600: "Semibold", 700: "Bold", 800: "Heavy", 900: "Black"}
	choices = {}
	for entry in font_manager.fontManager.ttflist:
		if entry.style != "normal" or entry.stretch != "normal" or entry.name.startswith("."):
			continue
		weight = font_manager.weight_dict.get(entry.weight, entry.weight)
		key = (entry.name, int(weight))
		if key in choices:
			continue
		try:
			font = ft2font.FT2Font(entry.fname)
			if not all(font.get_char_index(ord(char)) for char in "AHaz09"):
				continue
		except (OSError, RuntimeError):
			continue
		value = f"{entry.name}:{'bold' if weight == 700 else 'normal' if weight == 400 else weight}"
		choices[key] = {"value": value, "label": f"{entry.name} · {weights.get(weight, f'Weight {weight}')}"}
	preferred = {"DejaVu Sans": 0, "DejaVu Serif": 1, "DejaVu Sans Mono": 2}
	return [choices[key] for key in sorted(choices, key=lambda k: (preferred.get(k[0], 3), k[0].casefold(), k[1]))]


@functools.lru_cache(maxsize=512)
def glyph_sdf(char: str, font: str = "DejaVu Sans:bold") -> tuple[np.ndarray, float, float, float]:
	"""Signed distance map of `char` (px at cap height _CAP_HEIGHT), its centre (col, row) and bounding radius."""
	path = find_font(font)
	probe = ImageFont.truetype(path, 100)
	cap = probe.getbbox("H")
	font_obj = ImageFont.truetype(path, max(4, int(round(100 * _CAP_HEIGHT / (cap[3] - cap[1])))))

	left, top, right, bottom = font_obj.getbbox(char)
	if right <= left or bottom <= top:
		raise ValueError(f"Font {path} has no visible glyph for {char!r}")
	img = Image.new("L", (right - left + 2 * _PAD, bottom - top + 2 * _PAD), 0)
	ImageDraw.Draw(img).text((_PAD - left, _PAD - top), char, fill=255, font=font_obj)
	ink = np.asarray(img) >= 128

	sdf = ndimage.distance_transform_edt(~ink) - ndimage.distance_transform_edt(ink)
	sdf = np.where(ink, sdf + 0.5, sdf - 0.5).astype(np.float32)
	rows, cols = np.nonzero(ink)
	cx = 0.5 * (cols.min() + cols.max())
	cy = 0.5 * (rows.min() + rows.max())
	radius = float(np.sqrt((cols - cx) ** 2 + (rows - cy) ** 2).max()) + 1.0
	return sdf, cx, cy, radius
