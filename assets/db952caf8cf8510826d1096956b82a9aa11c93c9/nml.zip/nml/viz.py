"""Viewing and exporting stimuli: mp4/gif files, notebook display, filmstrips, space-time slices.

mp4 is for looking at, not for storage: 4:2:0 chroma smears 1-px noise, so frames
are upscaled with nearest neighbour before encoding. Keep the float/uint8 arrays as data.
"""

import base64
import os
import tempfile

import numpy as np
from PIL import Image
from scipy import ndimage

MP4_MAX_LONG_EDGE = 3840
MP4_MAX_SHORT_EDGE = 2160


def to_uint8(frames) -> np.ndarray:
	frames = np.asarray(frames)
	if frames.dtype == np.uint8:
		return frames
	return np.round(np.clip(frames, 0, 1) * 255).astype(np.uint8)


def to_rgb(frames) -> np.ndarray:
	frames = to_uint8(frames)
	return frames if frames.ndim == 4 else np.repeat(frames[..., None], 3, axis=-1)


def upscale(frames, scale: int) -> np.ndarray:
	return np.repeat(np.repeat(frames, scale, axis=1), scale, axis=2)


def tile(videos, gap: int = 2, value: float = 0.5) -> np.ndarray:
	"""Videos side by side (looping shorter ones), as RGB uint8 (T, H, W, 3)."""
	videos = [to_rgb(v) for v in videos]
	T = max(len(v) for v in videos)
	H = max(v.shape[1] for v in videos)
	fill = int(round(value * 255))
	parts = []
	for i, v in enumerate(videos):
		v = v[np.arange(T) % len(v)]
		if v.shape[1] < H:
			v = np.pad(v, ((0, 0), (0, H - v.shape[1]), (0, 0), (0, 0)), constant_values=fill)
		parts.append(v)
		if i < len(videos) - 1:
			parts.append(np.full((T, H, gap, 3), fill, dtype=np.uint8))
	return np.concatenate(parts, axis=2)


def outline(frames, masks, color=(255, 64, 64)) -> np.ndarray:
	"""Draw the contour of `masks` ((T, H, W) or (T, K, H, W)) on top of the frames, as RGB uint8."""
	rgb = to_rgb(frames).copy()
	masks = np.asarray(masks)
	if masks.ndim == 4:
		masks = masks.any(axis=1)
	edge = masks & ~ndimage.binary_erosion(masks, structure=np.ones((1, 3, 3), dtype=bool), border_value=0)
	rgb[edge] = color
	return rgb


def mp4_scale(width, height, requested):
	"""Fit landscape or portrait 4K, retaining integer-sized stimulus pixels when possible."""
	limit = min(MP4_MAX_LONG_EDGE / max(width, height), MP4_MAX_SHORT_EDGE / min(width, height))
	if limit >= 1:
		limit = int(limit)
	return min(requested, limit)


def scaled_size(width, height, scale):
	return max(1, int(width * scale)), max(1, int(height * scale))


def _export_image(frame, scale, overlays):
	"""Scale stimulus pixels first, then paste overlays already drawn at output resolution."""
	image = Image.fromarray(frame)
	size = scaled_size(image.width, image.height, scale)
	if size != image.size:
		image = image.resize(size, Image.Resampling.NEAREST)
	elif overlays:
		image = image.copy()
	for position, overlay in overlays:
		image.paste(overlay, position)
	return image


def save_mp4(frames, path, fps: int = 30, scale: int | None = None, crf: int = 12, *, overlays=()) -> str:
	"""Encode H.264 within portrait/landscape 4K; overlays use final output pixels."""
	import imageio.v2 as imageio

	frames = to_uint8(frames)
	scale = max(1, 512 // max(frames.shape[1:3])) if scale is None else scale
	scale = mp4_scale(frames.shape[2], frames.shape[1], scale)
	with imageio.get_writer(
			path, fps=fps, codec="libx264", pixelformat="yuv420p", macro_block_size=1,
			quality=None, ffmpeg_params=["-crf", str(crf), "-preset", "veryfast", "-movflags", "+faststart"],
	) as writer:
		for frame in frames:
			frame = np.asarray(_export_image(frame, scale, overlays).convert("RGB"))
			h, w = frame.shape[:2]
			if h % 2 or w % 2:
				frame = np.pad(frame, ((0, h % 2), (0, w % 2), (0, 0)))
			writer.append_data(frame)
	return str(path)


def save_gif(frames, path, fps: int = 30, scale: int | None = None, *, overlays=()) -> str:
	"""Encode frames with optional (position, PIL image) overlays in output pixels."""
	frames = to_uint8(frames)
	scale = max(1, 512 // max(frames.shape[1:3])) if scale is None else scale
	images = [_export_image(f, scale, overlays) for f in frames]
	# GIF stores 10 ms ticks. Round cumulative frame boundaries so fractional
	# ticks (e.g. 30 fps) do not shorten the clip a little more on every frame.
	ticks = np.rint(np.arange(len(images) + 1) * 100 / fps).astype(np.int64)
	durations = (np.diff(ticks) * 10).tolist()
	images[0].save(path, format="GIF", save_all=True, append_images=images[1:], duration=durations, loop=0)
	return str(path)


def mp4_bytes(frames, fps: int = 30, scale: int | None = None, *, overlays=()) -> bytes:
	with tempfile.TemporaryDirectory() as tmp:
		path = os.path.join(tmp, "video.mp4")
		save_mp4(frames, path, fps=fps, scale=scale, overlays=overlays)
		with open(path, "rb") as f:
			return f.read()


def show(frames, fps: int = 30, scale: int = 6, labels=None):
	"""Display a video, or a list of videos side by side, inline in a notebook."""
	from IPython.display import HTML

	videos = frames if isinstance(frames, (list, tuple)) else [frames]
	data = base64.b64encode(mp4_bytes(tile(videos), fps=fps, scale=scale)).decode()
	caption = ""
	if labels:
		caption = "<div style='font:12px monospace'>" + " | ".join(map(str, labels)) + "</div>"
	return HTML(
		f"<video autoplay loop muted playsinline style='image-rendering:pixelated' "
		f"src='data:video/mp4;base64,{data}'></video>{caption}"
	)


def xt_slice(frames, row: int | None = None) -> np.ndarray:
	"""Space-time slice (T, W) through one row; coherent motion shows up as oriented streaks."""
	frames = np.asarray(frames)
	return frames[:, frames.shape[1] // 2 if row is None else row, :]


def filmstrip(frames, n: int = 8, ax=None, title=None, gap: int = 2):
	"""Plot n evenly spaced frames in a row."""
	import matplotlib.pyplot as plt

	idx = np.linspace(0, len(frames) - 1, n).round().astype(int)
	strip = tile([np.asarray(frames)[i:i + 1] for i in idx], gap=gap, value=1.0)[0]
	if ax is None:
		_, ax = plt.subplots(figsize=(1.4 * n, 1.6))
	ax.imshow(strip, interpolation="nearest")
	ax.set_xticks([])
	ax.set_yticks([])
	if title:
		ax.set_title(title, fontsize=9, loc="left")
	return ax
