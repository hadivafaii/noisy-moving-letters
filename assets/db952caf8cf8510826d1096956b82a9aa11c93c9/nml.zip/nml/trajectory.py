"""Trajectories: per-frame poses (x, y, angle, scale).

Position = path geometry (parametrized by arc length) evaluated at the distance travelled,
which comes from initial velocity, acceleration, and an optional speed profile. Wall bounce is applied independently to any path,
using the visible shape at its current orientation and scale.
"""

import numpy as np


def speed_profile(kind, speed, frames, speed_end=0.0, ramp=0.25, sine_amp=0.8, sine_period=24.0) -> np.ndarray:
	"""Distance travelled at each frame (starts at 0). `kind` may also be an array of per-step speeds."""
	steps = frames - 1
	if steps <= 0:
		return np.zeros(frames)
	t = np.arange(steps) + 0.5
	if not isinstance(kind, str):
		v = np.broadcast_to(np.asarray(kind, dtype=float), (steps,))
	elif kind == "constant":
		v = np.full(steps, float(speed))
	elif kind == "linear":
		v = np.linspace(speed, speed_end, steps)
	elif kind == "sine":
		v = speed * (1 + sine_amp * np.sin(2 * np.pi * t / sine_period))
	elif kind == "trapezoid":
		envelope = np.clip(np.minimum(t, steps - t) / max(ramp * steps, 1e-9), 0, 1)
		v = envelope * speed * steps / envelope.sum()
	elif kind == "ease":
		tau = np.linspace(0, 1, frames)
		return speed * steps * (10 * tau ** 3 - 15 * tau ** 4 + 6 * tau ** 5)
	else:
		raise ValueError(f"Unknown speed profile {kind!r}")
	return np.concatenate([[0.0], np.cumsum(v)])


def fold(x, lo, hi):
	"""Reflect x into [lo, hi], as a ball bouncing between two walls."""
	if hi <= lo:
		return np.full_like(np.asarray(x, dtype=float), (lo + hi) / 2)
	period = 2 * (hi - lo)
	u = np.mod(np.asarray(x, dtype=float) - lo, period)
	return lo + np.where(u <= hi - lo, u, period - u)


def polyline_path(points, distance, closed=False):
	"""Positions at the given arc lengths along a polyline; open paths go back and forth."""
	points = np.asarray(points, dtype=float)
	if closed:
		points = np.vstack([points, points[:1]])
	seg = np.hypot(*np.diff(points, axis=0).T)
	cum = np.concatenate([[0.0], np.cumsum(seg)])
	total = cum[-1]
	if total == 0:
		return np.repeat(points[:1], len(distance), axis=0).T
	s = np.mod(distance, total) if closed else fold(distance, 0.0, total)
	return np.interp(s, cum, points[:, 0]), np.interp(s, cum, points[:, 1])


def catmull_rom(points, samples=64) -> np.ndarray:
	p = np.asarray(points, dtype=float)
	p = np.vstack([p[:1], p, p[-1:]])
	t = np.linspace(0, 1, samples, endpoint=False)[:, None]
	out = []
	for i in range(1, len(p) - 2):
		p0, p1, p2, p3 = p[i - 1], p[i], p[i + 1], p[i + 2]
		out.append(0.5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t ** 2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t ** 3))
	out.append(p[-2:-1])
	return np.vstack(out)


def travelled(m: dict, frames: int) -> np.ndarray:
	"""Distance along the path at each frame, from resolved motion parameters `m`. Bounces do not shorten it."""
	if m["path"] == "static":
		return np.zeros(frames)
	return speed_profile(
		m["profile"], m["speed"], frames,
		speed_end=m["speed_end"], ramp=m["ramp"], sine_amp=m["sine_amp"], sine_period=m["sine_period"],
	) + 0.5 * m.get("acceleration", 0.0) * np.arange(frames, dtype=float) ** 2


def _reflect_step(position, step, lo, hi):
	"""Advance one axis, retaining overshoot and the parity of all wall hits."""
	if hi == lo:
		return lo, 1
	span = hi - lo
	u = (np.clip(position, lo, hi) + step - lo) % (2 * span)
	if u == 0:
		return lo, -1 if step < 0 else 1
	if u == span:
		return hi, -1 if step > 0 else 1
	return lo + (u if u < span else 2 * span - u), 1 if u < span else -1


def _bounce_path(points, angles, scale, shape, width, height, tangents=None):
	"""Reflect path increments at the shape's current left/right/top/bottom edges.

	Rotation or growth can move a wall constraint inward. Project the centre into
	the new interval before advancing; never reserve room for a future larger size.
	When the shape outgrows an axis, reverse that axis's bounds: its footprint
	spans the canvas and can pan between opposite edge alignments. Pinning its
	centre instead would freeze a fixed-size carried texture despite nonzero speed.
	Heading alignment follows the outgoing reflected tangent, not a centred
	finite difference that incorrectly turns sideways at the contact frame.
	"""
	positions = np.empty_like(points)
	orientations = np.empty_like(angles)
	direction = np.ones(2)
	position = points[0].copy()
	for t in range(len(points)):
		def orientation():
			return angles[t] if tangents is None else angles[t] + np.arctan2(*(tangents[t] * direction)[::-1])

		angle = orientation()
		left, right, top, bottom = shape.bounds(angle, scale[t])
		edge_a, edge_b = np.array([-left, -top]), np.array([width - right, height - bottom])
		lo, hi = np.minimum(edge_a, edge_b), np.maximum(edge_a, edge_b)
		step = (points[t] - points[t - 1]) * direction if t else np.zeros(2)
		for axis in (0, 1):
			position[axis], reflection = _reflect_step(position[axis], step[axis], lo[axis], hi[axis])
			direction[axis] *= reflection
		if tangents is not None:
			# Facing the new heading may change an asymmetric shape's footprint.
			angle = orientation()
			left, right, top, bottom = shape.bounds(angle, scale[t])
			edge_a, edge_b = np.array([-left, -top]), np.array([width - right, height - bottom])
			position = np.clip(position, np.minimum(edge_a, edge_b), np.maximum(edge_a, edge_b))
		positions[t], orientations[t] = position, angle
	return positions, orientations


def make_poses(m: dict, frames: int, height: int, width: int, radius: float, rng: np.random.Generator, *, shape=None) -> np.ndarray:
	"""Poses (frames, 4) = (x, y, angle in rad, scale) from resolved motion parameters `m` (a MotionCfg as a dict of scalars)."""
	t = np.arange(frames, dtype=float)
	scale = (np.linspace(m["scale"], m["scale_end"], frames) if m.get("scale_end") is not None
		else m["scale"] * np.linspace(1.0, m["scale_change"], frames))
	start = np.array([m["start_x"] * width, m["start_y"] * height])
	heading = np.deg2rad(m["direction"])
	unit = np.array([np.cos(heading), np.sin(heading)])
	dist = travelled(m, frames)

	path = m["path"]
	if path == "static":
		x, y = np.full(frames, start[0]), np.full(frames, start[1])
	elif path == "line":
		x, y = start[0] + unit[0] * dist, start[1] + unit[1] * dist
	elif path == "circle":
		phase = heading + dist / m["radius"] if m["radius"] else np.full(frames, heading)
		x = start[0] + abs(m["radius"]) * np.cos(phase)
		y = start[1] + abs(m["radius"]) * np.sin(phase)
	elif path == "spline":
		controls = np.vstack([start, np.array([width, height]) * rng.random((max(int(m["waypoints"]), 2) - 1, 2))])
		x, y = polyline_path(catmull_rom(controls), dist)
	elif path == "lissajous":
		phi = np.linspace(0, 2 * np.pi, 2048, endpoint=False)
		ax, ay = width / 2, height / 2
		curve = np.stack([width / 2 + ax * np.sin(3 * phi + heading), height / 2 + ay * np.sin(2 * phi)], axis=1)
		x, y = polyline_path(curve, dist, closed=True)
	else:
		raise ValueError(f"Unknown path {path!r}")

	base_angle = (np.linspace(m["angle"], m["angle_end"], frames) if m.get("angle_end") is not None
		else m["angle"] + m["spin"] * t + 0.5 * m.get("angular_acceleration", 0.0) * t ** 2)
	angle = np.deg2rad(base_angle + m["wobble"] * np.sin(2 * np.pi * t / m["wobble_period"]))
	points = np.column_stack([x, y])
	tangents = None
	if m["align_heading"]:
		tangents = np.gradient(points, axis=0) if frames > 1 else np.zeros_like(points)
		tangents[np.linalg.norm(tangents, axis=1) <= 1e-9] = unit
	if m["bounce"]:
		if shape is None:
			# Preserve the radius-only API for external callers representing a disc.
			from nml.shapes import Circle
			shape = Circle(radius)
		points, angle = _bounce_path(points, angle, scale, shape, width, height, tangents)
	elif tangents is not None:
		angle = angle + np.arctan2(tangents[:, 1], tangents[:, 0])
	return np.column_stack([points, angle, scale])
