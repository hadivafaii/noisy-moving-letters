"""Noisy moving letters: videos of moving shapes whose visibility is carried by controllable spatiotemporal noise."""

from nml.config import (
	AppearanceCfg,
	MotionCfg,
	NoiseCfg,
	ObjectCfg,
	PRESETS,
	ShapeCfg,
	SharedObjectCfg,
	StimulusCfg,
	TextureCfg,
	VideoCfg,
	ViewCfg,
	benchmark_conditions,
	preset,
	sweep,
)
from nml.render import Sample, generate, resolve


__all__ = [
	"AppearanceCfg",
	"MotionCfg",
	"NoiseCfg",
	"ObjectCfg",
	"PRESETS",
	"Sample",
	"ShapeCfg",
	"SharedObjectCfg",
	"StimulusCfg",
	"TextureCfg",
	"VideoCfg",
	"ViewCfg",
	"benchmark_conditions",
	"generate",
	"preset",
	"resolve",
	"sweep",
]
