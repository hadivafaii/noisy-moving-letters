"""Optional allocation limits for the public explorer; local generation is unrestricted."""

from contextvars import ContextVar


allocation_budget = ContextVar("allocation_budget", default=None)


def check_allocation(elements, purpose):
	limit = allocation_budget.get()
	if limit is not None and elements > limit:
		raise ValueError(
			f"{purpose} needs {int(elements):,} elements, above the hosted limit of {limit:,}. "
			"Reduce the size, motion, density, or clip length, or run the explorer locally."
		)
