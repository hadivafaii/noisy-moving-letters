"""Leakage diagnostics: can a cheap observer tell figure pixels from ground pixels?

Each family of per-pixel features feeds a logistic-regression observer. It is fitted on a
few clips drawn from a configuration and scored (ROC AUC) on a fresh clip, so it measures
what the configuration leaks rather than the quirks of one random texture. The families:

	frame     single-frame local statistics: mean, variance, spatial autocorrelation, and
	          self-similarity under the frame's strongest shift (catches a shared texture)
	diff      local magnitude of frame differences (what |I_t - I_{t-1}| shows)
	temporal  per-pixel statistics over a short window: mean, variance, lag-1 autocorrelation
	motion    normalized opponent motion energy (Adelson & Bergen), the positive control

AUC ≈ 0.5 means the family carries no figure-ground information. For a motion-only
stimulus, the first three should sit at chance while motion stays high. Pixels near the
frame border are left out: filters behave differently there, and the figure rarely
touches the border, so the observer would otherwise learn position rather than figure.
"""

import numpy as np
from scipy import ndimage, stats


FAMILIES = ("frame", "diff", "temporal", "motion")
_EDGE = 4  # frames dropped at each end (temporal windows and FFT wrap-around)
_MARGIN = 6  # pixels dropped along the frame border


def _box(x, size):
	return ndimage.uniform_filter(x, size=(1, size, size), mode="nearest")


def _local_stats(v, size=5):
	m = _box(v, size)
	c = v - m
	return [
		m,
		_box(c * c, size),
		_box(c * np.roll(c, 1, axis=2), size),
		_box(c * np.roll(c, 1, axis=1), size),
	]


def _shift_similarity(frames, size=5, min_shift=3):
	"""Local similarity at each frame's strongest non-trivial circular shift."""
	T, H, W = frames.shape
	c = frames - frames.mean(axis=(1, 2), keepdims=True)
	spec = np.fft.rfft2(c)
	ac = np.fft.irfft2(spec * np.conj(spec), s=(H, W))
	dy = np.minimum(np.arange(H), H - np.arange(H))[:, None]
	dx = np.minimum(np.arange(W), W - np.arange(W))[None, :]
	ac[:, dy ** 2 + dx ** 2 < min_shift ** 2] = -np.inf
	out = np.empty_like(c)
	for t in range(T):
		sy, sx = np.unravel_index(np.argmax(ac[t]), (H, W))
		out[t] = c[t] * (np.roll(c[t], (-sy, -sx), axis=(0, 1)) + np.roll(c[t], (sy, sx), axis=(0, 1)))
	return _box(out, size)


def motion_energy(frames, speeds=(1.0, 2.0, 3.0), directions=8) -> np.ndarray:
	"""Normalized motion energy (channels, T, H, W) from quadrature spatiotemporal filters built in the Fourier domain."""
	T, H, W = frames.shape
	spec = np.fft.fftn(frames - frames.mean())
	ft = np.fft.fftfreq(T)[:, None, None]
	fy = np.fft.fftfreq(H)[None, :, None]
	fx = np.fft.fftfreq(W)[None, None, :]
	energy = []
	for speed in speeds:
		f0 = min(0.25, 0.3 / speed)
		sigma_s, sigma_t = 0.5 * f0, 0.5 * f0 * max(speed, 1.0)
		for k in range(directions):
			phi = 2 * np.pi * k / directions
			ux, uy = np.cos(phi), np.sin(phi)
			gain = np.exp(
				-((fx - f0 * ux) ** 2 + (fy - f0 * uy) ** 2) / (2 * sigma_s ** 2)
				- (ft + f0 * speed) ** 2 / (2 * sigma_t ** 2)
			)
			energy.append(np.abs(np.fft.ifftn(spec * gain)) ** 2)
	energy = np.stack(energy)
	return energy / (energy.sum(axis=0, keepdims=True) + 1e-12)


def features(frames, family: str) -> np.ndarray:
	"""Per-pixel features (F, T, H, W) of one family."""
	frames = np.asarray(frames)
	frames = frames / 255.0 if frames.dtype == np.uint8 else frames.astype(np.float64)
	if family == "frame":
		return np.stack(_local_stats(frames) + [_shift_similarity(frames)])
	if family == "diff":
		d = np.diff(frames, axis=0, prepend=frames[:1])
		m = _box(d, 5)
		return np.stack([m, _box(np.abs(d), 5), _box(d * d, 5) - m * m])
	if family == "temporal":
		w = 8
		m = ndimage.uniform_filter1d(frames, w, axis=0, mode="nearest")
		c = frames - m
		var = ndimage.uniform_filter1d(c * c, w, axis=0, mode="nearest")
		lag = ndimage.uniform_filter1d(c * np.roll(c, 1, axis=0), w, axis=0, mode="nearest")
		return np.stack([_box(v, 3) for v in (m, var, lag)])
	if family == "motion":
		e = np.stack([_box(c, 5) for c in motion_energy(frames)])
		deviation = np.linalg.norm(e - np.median(e, axis=(2, 3), keepdims=True), axis=0)
		return np.concatenate([e, deviation[None]])
	raise ValueError(f"Unknown family {family!r}; choices are {FAMILIES}")


def _auc(score, label) -> float:
	pos = label.sum()
	neg = label.size - pos
	if pos == 0 or neg == 0:
		return float("nan")
	ranks = stats.rankdata(score)
	return float((ranks[label].sum() - pos * (pos + 1) / 2) / (pos * neg))


def _logistic(X, y, l2=1e-3, iters=20):
	w = np.zeros(X.shape[1])
	for _ in range(iters):
		p = 1 / (1 + np.exp(-np.clip(X @ w, -30, 30)))
		grad = X.T @ (p - y) / len(y) + l2 * w
		hess = (X * (p * (1 - p))[:, None]).T @ X / len(y) + l2 * np.eye(X.shape[1])
		w -= np.linalg.solve(hess, grad)
	return w


def _design(feats, figure):
	"""Feature rows and labels, without the clip's first/last frames and border pixels."""
	T, H, W = figure.shape
	ts = slice(_EDGE, T - _EDGE) if T > 2 * _EDGE + 2 else slice(None)
	m = _MARGIN if min(H, W) > 4 * _MARGIN else 0
	rows, cols = slice(m, H - m), slice(m, W - m)
	return feats[:, ts, rows, cols].reshape(len(feats), -1).T, figure[ts, rows, cols].ravel()


def observer_auc(train, test, max_train=60000, seed=0) -> float:
	"""Fit a logistic observer on the `train` (features, figure) pairs and report its AUC on the `test` pair."""
	parts = [_design(f, m) for f, m in train]
	X = np.concatenate([p[0] for p in parts])
	y = np.concatenate([p[1] for p in parts])
	if y.all() or not y.any():
		return float("nan")
	if len(y) > max_train:
		idx = np.random.default_rng(seed).choice(len(y), max_train, replace=False)
		X, y = X[idx], y[idx]
	mu, sd = X.mean(axis=0), X.std(axis=0) + 1e-12
	design1 = lambda Z: np.hstack([(Z - mu) / sd, np.ones((len(Z), 1))])
	# Apple's Accelerate BLAS raises spurious floating-point flags in matmul; the values are finite.
	with np.errstate(divide="ignore", over="ignore", invalid="ignore"):
		w = _logistic(design1(X), y.astype(float))
		Xt, yt = _design(*test)
		return _auc(design1(Xt) @ w, yt)


def leakage(cfg_or_clips, seed=0, families=FAMILIES, n_train=3, n_test=3) -> dict:
	"""AUC per feature family, averaged over test clips.

	Pass a config, from which n_train + n_test independent clips are generated, or a list
	of (frames, figure mask) pairs whose last n_test items are the test clips. A persistent
	texture gives each clip a random figure-ground offset, so with the defaults a cue-free
	family still scatters around 0.5 (sd ≈ 0.03; deviations up to ≈ 0.08 happen). Use more
	clips, or several seeds, for a tighter estimate.
	"""
	if isinstance(cfg_or_clips, (list, tuple)):
		clips = [(np.asarray(f), np.asarray(m, dtype=bool)) for f, m in cfg_or_clips]
	else:
		from nml.render import generate

		clips = []
		for i in range(n_train + n_test):
			s = generate(cfg_or_clips, seed=(*np.atleast_1d(seed).tolist(), 7919, i))
			clips.append((s.frames, s.masks.any(axis=1)))
	n_test = min(n_test, len(clips) - 1)
	report = {}
	for family in families:
		feats = [(features(f, family), m) for f, m in clips]
		report[family] = float(np.nanmean([observer_auc(feats[:-n_test], test) for test in feats[-n_test:]]))
	return report


def format_report(report: dict) -> str:
	return " · ".join(f"{k} {v:.2f}" for k, v in report.items())
