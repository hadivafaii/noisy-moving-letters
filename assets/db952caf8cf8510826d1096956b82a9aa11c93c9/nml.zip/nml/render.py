"""Render a stimulus: layers -> frames plus ground truth.

Each pixel of each frame is owned by exactly one layer (the topmost object covering it, or
the background) and shows that layer's carried texture. Pixel values are built in a latent
space and then mapped to the configured marginal:

	u = a * ink + sqrt(1 - a²) * (sqrt(1 - λ) * texture + sqrt(λ) * fresh)

where a = form_contrast and λ = fresh_noise. With a = 0 every frame has exactly the target
marginal everywhere, so the shape lives only in how the texture moves.

Motion is specified in the world. The view decides where the eye looks: at a fixed point of
the screen (an ordinary video), or pursuing an object, which then stays at the frame centre
while the world streams past. Everything is drawn shifted by the eye's displacement, so the
two views of one seed show the same world.
"""

from dataclasses import dataclass, fields

import numpy as np

from nml.config import StimulusCfg, ShapeCfg, MotionCfg, as_config
from nml.shapes import make_shape, shape_chars
from nml.texture import DotLayer, gather_pixel_texture, splat_dots, to_pixels
from nml.trajectory import make_poses


INK = 2.0  # latent amplitude of the clean shape; Φ(2) ≈ 0.98, so a = 1 renders at nearly full contrast

# Independent random streams; each is seeded by (seed, stream, object index).
SCENE, FIG_TEX, FIG_DYN, BG_TEX, BG_DYN, NOISE, DITHER = range(7)


def rng_for(seed, *keys) -> np.random.Generator:
	return np.random.default_rng([*np.atleast_1d(seed).tolist(), *keys])


@dataclass
class Sample:
	frames: np.ndarray    # (T, H, W) float32 in [0, 1]
	masks: np.ndarray     # (T, K, H, W) bool, pixels each object owns (visible)
	amodal: np.ndarray    # (T, K, H, W) bool, full extent of each object, ignoring occlusion
	coverage: np.ndarray  # (T, K, H, W) float32, anti-aliased amodal coverage
	poses: np.ndarray     # (T, K, 4) float32 on screen: x, y (px), angle (rad, clockwise), scale
	labels: list          # per object: the character, or the shape kind
	params: list          # per object: resolved shape and motion parameters
	camera: np.ndarray    # (T, 2) float32, the eye's displacement (px); world position = screen position + camera
	flow: np.ndarray | None = None  # (T, H, W, 2) displacement of the visible texture from t to t + 1


def _draw(value, rng, integer=False):
	"""Resolve a possibly random field with exactly one draw."""
	u = rng.random()
	if isinstance(value, (list, tuple)):
		if len(value) == 2 and all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in value):
			if integer:
				lo, hi = sorted(int(round(v)) for v in value)
				return min(lo + int(u * (hi - lo + 1)), hi)
			return float(value[0] + u * (value[1] - value[0]))
		return value[min(int(u * len(value)), len(value) - 1)]
	return value


def _draw_all(cfg, rng, optional_rng=None) -> dict:
	return {f.name: _draw(getattr(cfg, f.name), optional_rng if (f.metadata.get("optional") or f.metadata.get("independent_rng")) and optional_rng is not None else rng, f.type is int) for f in fields(cfg)}


def resolve(cfg, seed=0) -> list[dict]:
	"""Draw each object's identity, shape and trajectory (in world coordinates). Depends only on the scene part of the config."""
	cfg = as_config(cfg).validate()
	v = cfg.video
	shared = cfg.shared_overrides()
	# A shared sampled value is drawn once for the scene. Consume a stable slot
	# for every shape/motion field so adding an override cannot reshuffle others.
	shared_rng = rng_for(seed, SCENE, 2 ** 32)
	for group, cls in [("shape", ShapeCfg), ("motion", MotionCfg)]:
		for f in fields(cls):
			path = f"{group}.{f.name}"
			value = _draw(shared.get(path), shared_rng, f.type is int)
			if path in shared:
				shared[path] = value
	objects = []
	for k, obj in enumerate(cfg.objects):
		rng = rng_for(seed, SCENE, k)
		shape_p = _draw_all(obj.shape, rng)
		# Added motion fields use their own stream so old seeds keep identities and paths.
		motion_p = _draw_all(obj.motion, rng, rng_for(seed, SCENE, k, 1))
		# Draw first so sharing never reshuffles an object's other random choices.
		# Apply overrides to the resolved copy, preserving each object's own values.
		for path, value in shared.items():
			group, name = path.split(".")
			if group in ("shape", "motion"):
				{"shape": shape_p, "motion": motion_p}[group][name] = value
		u = rng.random()
		if shape_p["kind"] in ("glyph", "atom"):
			chars = shape_chars(shape_p["kind"], shape_p["chars"])
			label = chars[min(int(u * len(chars)), len(chars) - 1)]
		else:
			label = shape_p["kind"]
		shape = make_shape(
			shape_p["kind"], char=label, size=shape_p["size"], thickness=shape_p["thickness"], length=shape_p["length"],
			aspect=shape_p["aspect"], sides=shape_p["sides"], outline=shape_p["outline"], font=shape_p["font"],
		)
		poses = make_poses(motion_p, v.frames, v.height, v.width, shape.radius, rng, shape=shape)
		objects.append({"shape": shape, "label": label, "poses": poses, "params": {**shape_p, **motion_p}})
	return objects


def camera_path(view, world, height, width) -> np.ndarray:
	"""The eye's displacement (T, 2) given the objects' world poses (T, K, 4): zero while it fixates the screen,
	`gain` times the target's offset from the frame centre while it pursues an object."""
	T, K = world.shape[:2]
	if view.fixate == "screen":
		return np.zeros((T, 2))
	if view.fixate != "object":
		raise ValueError(f"Unknown fixation {view.fixate!r}")
	k = int(view.target) - 1
	if not 0 <= k < K:
		raise ValueError(f"view.target = {view.target}, but the scene has {K} object(s)")
	return float(view.gain) * (world[:, k, :2] - np.array([width / 2, height / 2]))


def _background_offsets(noise, poses, frames) -> np.ndarray:
	"""Cumulative displacement (T, 2) of the background texture in the world."""
	if noise.bg_motion == "static":
		return np.zeros((frames, 2))
	if noise.bg_motion == "drift":
		step = noise.bg_speed * np.array([np.cos(np.deg2rad(noise.bg_direction)), np.sin(np.deg2rad(noise.bg_direction))])
		return np.arange(frames)[:, None] * step
	if noise.bg_motion == "matched":
		if poses is None:
			return np.zeros((frames, 2))
		a = np.deg2rad(noise.bg_angle)
		vel = np.diff(poses[:, :2], axis=0)
		vel = vel @ np.array([[np.cos(a), np.sin(a)], [-np.sin(a), np.cos(a)]])
		return np.concatenate([np.zeros((1, 2)), np.cumsum(vel, axis=0)])
	raise ValueError(f"Unknown background motion {noise.bg_motion!r}")


def _local_coordinates(xx, yy, pose):
	x, y, th, scale = pose
	dx, dy = xx - x, yy - y
	c, sn = np.cos(th), np.sin(th)
	return (c * dx + sn * dy) / scale, (-sn * dx + c * dy) / scale


def generate(cfg, seed=0, flow=False, objects=None) -> Sample:
	"""Render one clip. `objects` optionally replaces the configured objects with your own, as dicts
	{"shape": nml.shapes.Shape, "poses": (T, 4) array of x, y, angle, scale in the world, "label": str}."""
	cfg = as_config(cfg).validate()
	T, H, W = cfg.video.frames, cfg.video.height, cfg.video.width
	tex, noise = cfg.background_style()
	objects = resolve(cfg, seed) if objects is None else [{"label": "", "params": {}, **o} for o in objects]
	K = len(objects)
	world = np.stack([o["poses"] for o in objects], axis=1) if K else np.zeros((T, 0, 4))
	camera = camera_path(cfg.view, world, H, W)
	poses = world.copy()
	poses[:, :, :2] -= camera[:, None]

	yy, xx = np.mgrid[0:H, 0:W].astype(np.float64) + 0.5
	# Flow needs every object's coordinates later. Ordinary previews can compute
	# them per frame, then recompute one texture layer at a time below.
	qx = np.empty((K, T, H, W)) if flow else None
	qy = np.empty((K, T, H, W)) if flow else None
	coverage = np.empty((K, T, H, W), dtype=np.float32)
	amodal = np.empty((K, T, H, W), dtype=bool)
	for k, o in enumerate(objects):
		# Geometry has no temporal state. Sampling one frame at a time preserves
		# the exact pixels while avoiding several full-video float64 temporaries.
		for t, pose in enumerate(poses[:, k]):
			local_x, local_y = _local_coordinates(xx, yy, pose)
			if flow:
				qx[k, t], qy[k, t] = local_x, local_y
			dist = o["shape"].sdf(local_x, local_y) * pose[3]
			coverage[k, t] = np.clip(0.5 - dist, 0, 1)
			amodal[k, t] = dist < 0
	if noise.ownership == "dither":
		amodal = rng_for(seed, DITHER).random((T, H, W)) < coverage
	owner = np.zeros((T, H, W), dtype=np.int16)
	for k in range(K):
		owner[amodal[k]] = k + 1
	masks = owner[None] == np.arange(1, K + 1, dtype=np.int16)[:, None, None, None]

	# Texture offsets on screen: the background's, and the drift of world-fixed figure textures, both minus the eye's
	# motion. Object-fixed figure textures drift in the object's own coordinates.
	bg_off = _background_offsets(noise, world[:, 0] if K else None, T) - camera
	styles = [cfg.object_style(k) for k in range(K)]
	noisy = noise.form_contrast < 1 or any(n.form_contrast < 1 for _, n in styles)
	carrier = (_render_carrier(cfg, seed, objects, styles, world, poses, camera, owner, qx, qy, xx, yy, bg_off)
		if noisy else np.zeros((T, H, W), dtype=np.float32))
	if not flow:
		# Only optional flow needs the geometry after the carrier has been sampled.
		del qx, qy
	fresh = (rng_for(seed, NOISE).standard_normal((T, H, W), dtype=np.float32)
		if noise.fresh_noise > 0 or any(n.fresh_noise > 0 for _, n in styles) else None)
	frames = np.empty((T, H, W), dtype=np.float32)
	for t in range(T):
		# Pixel mapping is elementwise. Keep its float64 temporaries to one frame.
		combined_coverage = coverage[:, t].max(axis=0) if K else np.zeros((H, W))
		fresh_t = None if fresh is None else fresh[t]
		frames[t] = _layer_pixels(carrier[t], combined_coverage, tex, noise, fresh_t)
		for k, (obj_tex, obj_noise) in enumerate(styles):
			if obj_tex == tex and obj_noise == noise:
				continue
			# Only visible pixels belong to this object, including when objects overlap.
			mine = owner[t] == k + 1
			frames[t, mine] = _layer_pixels(carrier[t, mine], coverage[k, t, mine], obj_tex, obj_noise,
				None if fresh_t is None else fresh_t[mine])

	sample = Sample(
		frames=frames,
		masks=masks.transpose(1, 0, 2, 3),
		amodal=amodal.transpose(1, 0, 2, 3),
		coverage=coverage.transpose(1, 0, 2, 3),
		poses=poses.astype(np.float32),
		labels=[o["label"] for o in objects],
		params=[o["params"] for o in objects],
		camera=camera.astype(np.float32),
	)
	if flow:
		sample.flow = _texture_flow(styles, poses, camera, owner, qx, qy, xx, yy, bg_off)
	return sample


def _layer_pixels(carrier, coverage, tex, noise, fresh):
	a, lam = float(noise.form_contrast), float(noise.fresh_noise)
	sign = -1.0 if tex.ink == "dark" else 1.0
	u = a * sign * INK * (2 * coverage - 1)
	if a < 1:
		mixed = np.sqrt(1 - lam) * carrier
		if lam > 0:
			mixed += np.sqrt(lam) * fresh
		u = u + np.sqrt(1 - a * a) * mixed
	return np.clip(0.5 + 0.5 * u, 0, 1).astype(np.float32) if tex.carrier == "dots" else to_pixels(u, tex)


def _drift(noise, frames):
	direction = np.deg2rad(noise.texture_direction)
	return noise.texture_speed * np.arange(frames)[:, None] * np.array([np.cos(direction), np.sin(direction)])


def _render_carrier(cfg, seed, objects, styles, world, poses, camera, owner, qx, qy, xx, yy, bg_off):
	T, H, W = owner.shape
	out = np.zeros((T, H, W), dtype=np.float32)
	for layer_index, (tex, noise) in enumerate([cfg.background_style(), *styles]):
		background = layer_index == 0
		k = layer_index - 1
		coherence = noise.bg_coherence if background else noise.coherence
		if coherence is None:
			coherence = styles[0][1].coherence if styles else noise.coherence
		tex_rng = rng_for(seed, BG_TEX) if background else rng_for(seed, FIG_TEX, k)
		dyn_rng = rng_for(seed, BG_DYN) if background else rng_for(seed, FIG_DYN, k)
		drift = _drift(noise, T)
		in_world = noise.texture_frame == "world"
		mine = owner == layer_index
		gain = 1 if background else noise.texture_gain
		if tex.carrier == "pixel":
			if background or in_world:
				offset = bg_off if background else drift - camera
				tx = xx[None] - offset[:, 0, None, None]
				ty = yy[None] - offset[:, 1, None, None]
			else:
				# Geometry uses scaled local coordinates; texture can instead use
				# rigid local coordinates so grain and blur stay constant on screen.
				tx, ty = np.empty((T, H, W)), np.empty((T, H, W))
				for t, pose in enumerate(poses[:, k]):
					local_x, local_y = (_local_coordinates(xx, yy, pose) if qx is None else (qx[k, t], qy[k, t]))
					texture_scale = pose[3] if noise.texture_scale_compensation else 1.0
					tx[t] = local_x * texture_scale - drift[t, 0]
					ty[t] = local_y * texture_scale - drift[t, 1]
			fig = np.zeros_like(out)
			gather_pixel_texture(tx, ty, mine, int(tex.grain), tex.blur, float(coherence), noise.coherence_mode,
				tex_rng, dyn_rng, fig)
			out += gain * fig
			del tx, ty, fig
			continue

		shape = None if background or in_world else objects[k]["shape"]
		dots = DotLayer(tex_rng, tex.dot_density, tex.dot_polarity, float(coherence), noise.coherence_mode,
			noise.coherent_fraction, shape=shape, frame=(W, H) if shape is None else None)
		bg_world = bg_off + camera
		for t in range(T):
			eye = camera[t - 1] - camera[t] if t else np.zeros(2)
			if background:
				step = bg_world[t] - bg_world[t - 1] if t else np.zeros(2)
				pos = dots.step(step, np.hypot(*step), first=t == 0, carry=eye)
			else:
				step = drift[t] - drift[t - 1] if t else np.zeros(2)
				if in_world:
					pos = dots.step(step, np.hypot(*step), first=t == 0, carry=eye)
				else:
					x, y, th, scale = poses[t, k]
					speed = np.hypot(*(world[t, k, :2] - world[t - 1, k, :2])) if t else 0.0
					pos = dots.step(step, speed / scale, target_scale=scale, first=t == 0)
					c, sn = np.cos(th), np.sin(th)
					pos = np.stack([x + scale * (c * pos[:, 0] - sn * pos[:, 1]),
						y + scale * (sn * pos[:, 0] + c * pos[:, 1])], axis=1)
			img = splat_dots(pos, dots.amp, tex.dot_size, H, W)
			out[t] += np.where(mine[t], gain * img, 0)
	return out


def _texture_flow(styles, poses, camera, owner, qx, qy, xx, yy, bg_off) -> np.ndarray:
	"""Where the texture visible at each pixel goes on the next frame (last frame repeats the previous)."""
	T = owner.shape[0]
	flow = np.zeros(owner.shape + (2,), dtype=np.float32)
	drifts = [_drift(n, T) for _, n in styles]
	for t in range(T - 1):
		f = np.broadcast_to(bg_off[t + 1] - bg_off[t], owner.shape[1:] + (2,)).copy()
		for k in range(poses.shape[1]):
			mine = owner[t] == k + 1
			noise = styles[k][1]
			window = drifts[k] - camera
			drift_step = drifts[k][t + 1] - drifts[k][t]
			if noise.texture_frame == "world":
				f[mine] = window[t + 1] - window[t]
				continue
			x, y, th, s = poses[t + 1, k]
			c, sn = np.cos(th), np.sin(th)
			fixed_pixels = styles[k][0].carrier == "pixel" and noise.texture_scale_compensation
			texture_scale = poses[t, k, 3] if fixed_pixels else 1.0
			if fixed_pixels:
				s = 1.0
			px = qx[k, t] * texture_scale + drift_step[0]
			py = qy[k, t] * texture_scale + drift_step[1]
			f[mine, 0] = (x + s * (c * px - sn * py) - xx)[mine]
			f[mine, 1] = (y + s * (sn * px + c * py) - yy)[mine]
		flow[t] = f
	if T > 1:
		flow[-1] = flow[-2]
	return flow
