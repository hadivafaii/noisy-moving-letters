"""Declarative stimulus configuration.

A `StimulusCfg` is plain data: it round-trips through JSON, and the explorer builds its
controls from the field metadata below. Shape and motion fields may hold a list instead
of a single value: a numeric `[lo, hi]` pair is drawn uniformly per sample, any other list is a set
of choices. Each such field consumes exactly one random number, so fixing or freeing
one field never reshuffles the others.
"""

import copy
import itertools
import math
from dataclasses import MISSING, asdict, dataclass, field, fields, is_dataclass


SHAPE_KINDS = ("glyph", "atom", "bar", "square", "diamond", "rect", "triangle", "ngon", "circle", "ellipse")
PATHS = ("static", "line", "circle", "spline", "lissajous")
PROFILES = ("constant", "linear", "ease", "trapezoid", "sine")
MARGINALS = ("binary", "uniform", "gaussian", "laplace", "levels")


def _ui(default, **meta):
	"""A field plus UI metadata. `show` lists the values of other fields under which the field applies; its keys
	name a sibling field, or a dotted path from the config root. `scales` marks lengths and speeds that grow with
	the scene when the explorer rescales it (the noise grain stays one pixel)."""
	meta = {k: v for k, v in meta.items() if v is not None}
	if isinstance(default, (list, dict)):
		return field(default_factory=lambda: copy.deepcopy(default), metadata=meta)
	return field(default=default, metadata=meta)


@dataclass
class VideoCfg:
	height: int = _ui(256, min=8, max=512, step=1, unit="px", scales=True, help="Frame height (px)")
	width: int = _ui(256, min=8, max=512, step=1, unit="px", scales=True, help="Frame width (px)")
	frames: int = _ui(48, min=2, max=300, step=1, help="Number of frames")
	fps: int = _ui(30, min=1, max=120, step=1, help="Playback rate for mp4/gif and the explorer; does not change the stimulus")


@dataclass
class ShapeCfg:
	kind: str = _ui("glyph", choices=SHAPE_KINDS, help="glyph = font character; atom = letter built from straight stroke atoms")
	chars: str = _ui("A", show={"kind": ["glyph", "atom"]}, help="Alphabet spec (upper, lower, digits; comma-separated) or literal characters. One is drawn per sample")
	font: str = _ui("DejaVu Sans:bold", show={"kind": ["glyph"]}, help="Font family[:weight], or a path to a .ttf/.otf file")
	size: float = _ui(128.0, min=4, max=512, step=1, sampled=True, unit="px", scales=True, show={"kind": [k for k in SHAPE_KINDS if k != "bar"]}, help="Height (px): cap height of a glyph, side of a square or diamond, diameter of a circle or n-gon")
	thickness: float = _ui(5.0, min=1, max=20, step=0.5, sampled=True, unit="px", scales=True, show={"kind": ["atom", "bar"]}, help="Stroke thickness (px)")
	length: float = _ui(128.0, min=2, max=512, step=1, sampled=True, unit="px", scales=True, show={"kind": ["bar"]}, help="Bar length (px)")
	aspect: float = _ui(1.5, min=0.2, max=5, step=0.05, sampled=True, show={"kind": ["rect", "ellipse"]}, help="Width / height")
	sides: int = _ui(5, min=3, max=12, step=1, sampled=True, show={"kind": ["ngon"]}, help="Number of polygon sides")
	outline: float = _ui(0.0, min=0, max=10, step=0.5, unit="px", scales=True, help="0 = filled; >0 keeps only the outline, with this width (px)")


@dataclass
class MotionCfg:
	path: str = _ui("line", choices=PATHS, help="Path geometry; velocity and acceleration determine travel along it")
	bounce: bool = _ui(True, help="Reflect when the object's visible edge reaches a canvas wall. Oversized objects pan between opposite edge alignments instead of stopping. Independent of path and speed profile; turn off to allow the object to leave the canvas")
	start_x: float = _ui(0.25, min=0, max=1, step=0.01, sampled=True, unit="× W", show={"path": ["static", "line", "circle", "spline"]}, help="Start as a fraction of the width (circle: centre)")
	start_y: float = _ui(0.5, min=0, max=1, step=0.01, sampled=True, unit="× H", show={"path": ["static", "line", "circle", "spline"]}, help="Start as a fraction of the height (circle: centre)")
	direction: float = _ui(0.0, min=0, max=360, step=1, sampled=True, unit="°", help="Heading (deg): 0 = right, 90 = down. Phase for circle and lissajous")
	speed: float = _ui(0.0, min=-8, max=8, step=0.05, sampled=True, unit="px/f", scales=True, help="Initial linear velocity along the chosen direction or path (px/frame). Negative values reverse travel")
	profile: str = _ui("constant", choices=PROFILES, help="Speed along the path over time")
	speed_end: float = _ui(0.0, min=0, max=8, step=0.05, sampled=True, unit="px/f", scales=True, show={"profile": ["linear"]}, help="Final speed; the speed ramps linearly from `speed`")
	ramp: float = _ui(0.25, min=0.01, max=0.5, step=0.01, show={"profile": ["trapezoid"]}, help="Fraction of the clip spent accelerating, and again decelerating")
	sine_amp: float = _ui(0.8, min=0, max=1, step=0.01, show={"profile": ["sine"]}, help="Relative speed modulation")
	sine_period: float = _ui(24.0, min=2, max=300, step=1, unit="f", show={"profile": ["sine"]}, help="Modulation period (frames)")
	radius: float = _ui(16.0, min=-64, max=64, step=0.5, sampled=True, unit="px", scales=True, show={"path": ["circle"]}, help="Orbit radius (px); positive = clockwise")
	waypoints: int = _ui(4, min=2, max=12, step=1, show={"path": ["spline"]}, help="Random control points of the spline, including the start")
	angle: float = _ui(0.0, min=-180, max=180, step=1, sampled=True, unit="°", help="Initial orientation (deg, clockwise)")
	spin: float = _ui(0.0, min=-20, max=20, step=0.1, sampled=True, unit="°/f", help="Angular velocity (deg/frame)")
	wobble: float = _ui(0.0, min=0, max=90, step=1, unit="°", help="Orientation oscillation amplitude (deg)")
	wobble_period: float = _ui(24.0, min=2, max=300, step=1, unit="f", help="Orientation oscillation period (frames)")
	align_heading: bool = _ui(False, help="Add the instantaneous heading to the orientation")
	scale: float = _ui(1.0, min=0.2, max=3, step=0.01, sampled=True, unit="×", help="Initial scale, multiplying the shape's size")
	scale_change: float = _ui(1.0, min=0.2, max=5, step=0.01, unit="×", help="Final / initial scale (>1 looms)")
	# Optional endpoints leave legacy spin and relative-scale configurations unchanged.
	angle_end: float = _ui(None, optional=True, min=-360, max=360, step=1, sampled=True, unit="°", help="Final base orientation in degrees; interpolate from angle over the clip. None keeps the legacy spin behavior. Wobble and heading alignment are additional effects")
	scale_end: float = _ui(None, optional=True, min=0.01, max=5, step=0.01, sampled=True, unit="×", help="Final absolute size multiplier; interpolate from scale over the clip. None keeps the legacy relative scale change")
	acceleration: float = _ui(0.0, independent_rng=True, min=-2, max=2, step=0.01, sampled=True, unit="px/f²", scales=True, help="Change in linear velocity each frame, along the chosen direction or path. Negative acceleration slows positive velocity and can reverse it. With the constant profile, displacement is velocity × time + ½ × acceleration × time²")
	angular_acceleration: float = _ui(0.0, independent_rng=True, min=-5, max=5, step=0.01, sampled=True, unit="°/f²", help="Change in angular velocity each frame. Rotation = initial rotation + angular velocity × time + ½ × angular acceleration × time²")


@dataclass
class ObjectCfg:
	shape: ShapeCfg = field(default_factory=ShapeCfg)
	motion: MotionCfg = field(default_factory=MotionCfg)
	# Sparse appearance overrides inherit the legacy scene defaults when absent.
	overrides: dict = field(default_factory=dict)


@dataclass
class TextureCfg:
	carrier: str = _ui("pixel", choices=("pixel", "dots"), help="pixel = dense noise texture; dots = sparse random dots on grey")
	marginal: str = _ui("binary", choices=MARGINALS, show={"carrier": ["pixel"]}, help="Distribution of pixel values. At zero shape visibility and equal texture contrast, figure and background pixels have the same marginal distribution")
	p_on: float = _ui(0.5, min=0.01, max=0.99, step=0.01, show={"carrier": ["pixel"], "marginal": ["binary"]}, help="P(pixel = hi)")
	lo: float = _ui(0.0, min=0, max=1, step=0.01, show={"carrier": ["pixel"], "marginal": ["binary", "uniform", "levels"]}, help="Lowest value")
	hi: float = _ui(1.0, min=0, max=1, step=0.01, show={"carrier": ["pixel"], "marginal": ["binary", "uniform", "levels"]}, help="Highest value")
	spread: float = _ui(0.15, min=0.01, max=0.5, step=0.01, show={"carrier": ["pixel"], "marginal": ["gaussian", "laplace"]}, help="Standard deviation (gaussian) or scale (laplace) around 0.5; clipped to [0, 1]")
	levels: int = _ui(4, min=2, max=16, step=1, show={"carrier": ["pixel"], "marginal": ["levels"]}, help="Number of equiprobable grey levels")
	grain: int = _ui(1, min=1, max=8, step=1, unit="px", show={"carrier": ["pixel"]}, help="Texel size (px). >1 leaks a lattice cue at the outline")
	blur: float = _ui(0.0, min=0, max=4, step=0.1, unit="px", show={"carrier": ["pixel"]}, help="Spatial correlation of the texture (px). >0 leaks a seam cue at the outline")
	dot_density: float = _ui(0.08, min=0.005, max=0.5, step=0.005, unit="/px²", show={"carrier": ["dots"]}, help="Dots per px²")
	dot_size: float = _ui(2.0, min=0.5, max=6, step=0.1, unit="px", scales=True, show={"carrier": ["dots"]}, help="Dot diameter (px)")
	dot_polarity: str = _ui("both", choices=("both", "white", "black"), show={"carrier": ["dots"]}, help="Dot colour on grey")
	ink: str = _ui("dark", choices=("dark", "light"), help="Polarity of the clean, luminance-defined shape")


@dataclass
class NoiseCfg:
	form_contrast: float = _ui(1.0, min=0, max=1, step=0.01, help="1 = clean luminance-defined shape; 0 = the shape is carried only by the texture's motion")
	coherence: float = _ui(1.0, min=0, max=1, step=0.01, help="Temporal coherence of the figure texture: 1 = persists, 0 = resampled every frame")
	coherence_mode: str = _ui("refresh", choices=("refresh", "lifetime", "ar1"), help="refresh: each texel is resampled with probability 1 - coherence per frame. lifetime: fixed lifetime of 1 / (1 - coherence) frames, random phase. ar1: z <- c z + sqrt(1 - c²) noise")
	bg_coherence: float | None = _ui(1.0, min=0, max=1, step=0.01, nullable="same as figure", same_as="noise.coherence", help="1 keeps the background texture unchanged; 0 redraws it every frame. Independent of object coherence unless linked")
	fresh_noise: float = _ui(0.0, min=0, max=1, step=0.01, help="Fraction of independent per-frame noise, never carried by motion")
	coherent_fraction: float = _ui(1.0, min=0, max=1, step=0.01, show={"texture.carrier": ["dots"]}, help="Dots only: fraction of dots that follow their layer; the rest move in random directions relative to it, at its speed")
	texture_gain: float = _ui(1.0, min=0, max=2, step=0.01, help="Figure texture contrast relative to the background. ≠1 is a single-frame cue (no effect on a binary marginal with p_on = 0.5)")
	texture_frame: str = _ui("object", choices=("object", "world"), help="object = texture carried by the shape; world = the shape is a window onto its own flowing texture")
	texture_scale_compensation: bool = _ui(True, toggle=True, show={"texture.carrier": ["pixel"], "texture_frame": ["object"]}, help="Keep noise pixels the same size on screen as the object grows or shrinks. The texture still follows object position and rotation; scaling reveals or hides more texture. Off restores pixels that grow and shrink with the shape. Applies to attached pixel textures; world-coordinate textures and dot diameters already stay fixed")
	texture_speed: float = _ui(0.0, min=0, max=8, step=0.05, unit="px/f", scales=True, help="Extra drift of the figure texture (px/frame)")
	texture_direction: float = _ui(0.0, min=0, max=360, step=1, unit="°", help="Drift direction (deg); relative to the object when texture_frame = object")
	bg_motion: str = _ui("static", choices=("static", "drift", "matched"), help="Background texture motion in the world. matched = speed of object 1, at bg_angle from its heading, so per-pixel temporal statistics match the figure (other objects are not matched)")
	bg_angle: float = _ui(180.0, min=0, max=360, step=1, unit="°", show={"bg_motion": ["matched"]}, help="Angle between background and figure motion (deg)")
	bg_speed: float = _ui(2.0, min=0, max=8, step=0.05, unit="px/f", scales=True, show={"bg_motion": ["drift"]}, help="Background speed (px/frame)")
	bg_direction: float = _ui(180.0, min=0, max=360, step=1, unit="°", show={"bg_motion": ["drift"]}, help="Background direction (deg)")
	ownership: str = _ui("hard", choices=("hard", "dither"), help="hard: a pixel shows the layer covering its centre. dither: chosen with probability equal to the sub-pixel coverage")


@dataclass
class ViewCfg:
	fixate: str = _ui("screen", choices=("screen", "object"), help="Where the eye looks. screen: a fixed point, as in an ordinary video. object: the eye pursues the target object, which stays at the frame centre while the background and any other object stream past")
	target: int = _ui(1, min=1, max=8, step=1, show={"fixate": ["object"]}, help="Object the eye pursues (1 = the first object)")
	gain: float = _ui(1.0, min=0, max=1, step=0.01, label="pursuit gain", show={"fixate": ["object"]}, help="1 holds the target still. Below 1 the eye lags, and the target keeps (1 - gain) of its motion on screen")


def appearance_fields():
	return {"texture." + f.name for f in fields(TextureCfg)} | {
		"noise." + f.name for f in fields(NoiseCfg)
		if not f.name.startswith("bg_") and f.name != "ownership"
	}


def common_appearance_fields():
	"""Comparable settings supported by both objects and the background."""
	return {"texture." + f.name for f in fields(TextureCfg)} | {
		"noise." + name for name in (
			"form_contrast", "coherence", "coherence_mode", "fresh_noise", "coherent_fraction",
		)
	}


@dataclass
class AppearanceCfg:
	"""Common values, with sparse background exceptions; object exceptions stay on objects."""
	overrides: dict = field(default_factory=dict)
	background_overrides: dict = field(default_factory=dict)


def object_fields():
	return appearance_fields() | {
		group + "." + f.name
		for group, cls in [("shape", ShapeCfg), ("motion", MotionCfg)] for f in fields(cls)
	}


def flatten_overrides(value, prefix="overrides"):
	"""Validate the container before interpreting any paths from saved JSON."""
	if not isinstance(value, dict):
		raise ValueError(f"{prefix} must be a JSON object")
	result = {}
	for group, entries in value.items():
		if group not in ("shape", "motion", "texture", "noise") or not isinstance(entries, dict):
			raise ValueError(f"{prefix}.{group}: invalid settings group")
		for name, setting in entries.items():
			result[f"{group}.{name}"] = setting
	return result


@dataclass
class SharedObjectCfg:
	"""Optional overrides; each object's own values remain stored independently."""
	bounce_enabled: bool = _ui(False, help="Use one bounce setting for every object, keeping individual choices for when sharing is turned off")
	bounce: bool = _ui(True, label="Bounce at edges", object_field="motion.bounce", enabled_by="bounce_enabled", help="Whether every object bounces at the canvas walls while this setting is shared")
	overrides: dict = field(default_factory=dict)


@dataclass
class StimulusCfg:
	video: VideoCfg = field(default_factory=VideoCfg)
	objects: list[ObjectCfg] = field(default_factory=lambda: [ObjectCfg()])
	texture: TextureCfg = field(default_factory=TextureCfg)
	noise: NoiseCfg = field(default_factory=NoiseCfg)
	view: ViewCfg = field(default_factory=ViewCfg)
	shared: SharedObjectCfg = field(default_factory=SharedObjectCfg)
	appearance: AppearanceCfg = field(default_factory=AppearanceCfg)

	def to_dict(self) -> dict:
		data = asdict(self)
		# Keep existing JSON unchanged until generic overrides are actually used.
		for obj in [data["shared"], *data["objects"]]:
			if not obj["overrides"]:
				del obj["overrides"]
		if not self.appearance.overrides and not self.appearance.background_overrides:
			del data["appearance"]
		return data

	def shared_overrides(self) -> dict:
		"""Enabled object-field overrides, without changing stored object settings."""
		legacy = {
			f.metadata["object_field"]: getattr(self.shared, f.name)
			for f in fields(self.shared)
			if "object_field" in f.metadata and getattr(self.shared, f.metadata["enabled_by"])
		}
		return {**legacy, **flatten_overrides(self.shared.overrides)}

	def object_style(self, index):
		"""Effective texture and noise, leaving stored individual choices intact."""
		tex, noise = copy.deepcopy(self.texture), copy.deepcopy(self.noise)
		own = self.objects[index].overrides if index < len(self.objects) else {}
		for path, value in {**flatten_overrides(self.appearance.overrides), **flatten_overrides(own), **self.shared_overrides()}.items():
			group, name = path.split(".")
			if group in ("texture", "noise"):
				setattr(tex if group == "texture" else noise, name, copy.deepcopy(value))
		return tex, noise

	def background_style(self):
		"""Resolve common values without changing legacy settings or random streams."""
		tex, noise = copy.deepcopy(self.texture), copy.deepcopy(self.noise)
		for path, value in {**flatten_overrides(self.appearance.overrides),
				**flatten_overrides(self.appearance.background_overrides)}.items():
			group, name = path.split(".")
			if path == "noise.coherence":
				name = "bg_coherence"
			setattr(tex if group == "texture" else noise, name, copy.deepcopy(value))
		return tex, noise

	@classmethod
	def from_dict(cls, data: dict) -> "StimulusCfg":
		cfg = _from_dict(cls, data)
		cfg.validate()
		return cfg

	def validate(self):
		"""Reject malformed values before rendering; UI maxima are suggestions, not API limits."""
		def check(obj, prefix=""):
			for f in fields(obj):
				v = getattr(obj, f.name)
				path = prefix + f.name
				if f.name in ("overrides", "background_overrides"):
					allowed = (common_appearance_fields() if isinstance(obj, AppearanceCfg)
						else object_fields() if isinstance(obj, SharedObjectCfg) else appearance_fields())
					for key, value in flatten_overrides(v, path).items():
						if key not in allowed:
							raise ValueError(f"{path}.{key}: not an object setting")
						group, name = key.split(".")
						if f.name == "background_overrides" and key == "noise.coherence":
							name = "bg_coherence"
						entry = {"shape": ShapeCfg, "motion": MotionCfg, "texture": TextureCfg, "noise": NoiseCfg}[group]()
						setattr(entry, name, value)
						check(entry, path + "." + group + ".")
					continue
				if is_dataclass(v):
					check(v, path + ".")
					continue
				if f.name == "objects":
					if not isinstance(v, list) or any(not isinstance(o, ObjectCfg) for o in v):
						raise ValueError("objects must be a list of ObjectCfg values")
					for i, o in enumerate(v):
						check(o, f"objects.{i}.")
					continue
				if v is None and (f.name == "bg_coherence" or f.metadata.get("optional")):
					continue
				values = v if isinstance(v, (list, tuple)) else [v]
				if isinstance(v, (list, tuple)) and not isinstance(obj, (ShapeCfg, MotionCfg)):
					raise ValueError(f"{path}: random choices are supported only for shape and motion fields")
				if not values:
					raise ValueError(f"{path}: choices cannot be empty")
				for x in values:
					if "choices" in f.metadata:
						valid = x in f.metadata["choices"]
					elif f.type is str:
						valid = isinstance(x, str) and bool(x.strip())
					elif f.type is bool:
						valid = isinstance(x, bool)
					else:
						valid = isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)
						if valid and f.type is int:
							valid = isinstance(x, int)
						if valid and "min" in f.metadata and f.metadata["min"] >= 0:
							valid = x >= f.metadata["min"]
						if valid and f.metadata.get("max") == 1:
							valid = x <= 1
					if not valid:
						raise ValueError(f"{path}: invalid value {x!r}")
		check(self)
		for tex, noise in [self.background_style(), *(self.object_style(i) for i in range(len(self.objects)))]:
			if tex.lo > tex.hi:
				raise ValueError("texture.lo must be no greater than texture.hi")
			if not 0 < tex.p_on < 1:
				raise ValueError("texture.p_on must be between 0 and 1 (exclusive)")
			if tex.carrier == "dots" and noise.coherence_mode == "ar1":
				raise ValueError("Dot textures support refresh or lifetime coherence, not ar1")
		return self

	def replace(self, overrides: dict) -> "StimulusCfg":
		"""Return a copy with dotted-path overrides applied, e.g. {"noise.coherence": 0.5, "objects.0.shape.kind": "bar"}."""
		data = self.to_dict()
		for path, value in overrides.items():
			*parents, last = path.split(".")
			node = data
			for key in parents:
				if isinstance(node, list):
					node = node[int(key)]
				elif key in node:
					node = node[key]
				elif "overrides" in parents or "background_overrides" in parents:
					node = node.setdefault(key, {})
				else:
					raise KeyError(f"Unknown config path {path!r}")
			if isinstance(node, list):
				node[int(last)] = copy.deepcopy(value)
			elif last in node or "overrides" in parents or "background_overrides" in parents:
				node[last] = copy.deepcopy(value)
			else:
				raise KeyError(f"Unknown config path {path!r}")
		return StimulusCfg.from_dict(data)


def _from_dict(cls, data):
	if not isinstance(data, dict):
		raise ValueError(f"{cls.__name__} must be a JSON object")
	unknown = set(data) - {f.name for f in fields(cls)}
	if unknown:
		raise ValueError(f"Unknown {cls.__name__} field(s): {sorted(unknown)}")
	obj = cls()
	for f in fields(cls):
		if f.name not in data:
			continue
		value, current = data[f.name], getattr(obj, f.name)
		if is_dataclass(current):
			value = _from_dict(type(current), value)
		elif f.name == "objects":
			value = [_from_dict(ObjectCfg, v) for v in value]
		setattr(obj, f.name, value)
	return obj


def as_config(cfg) -> StimulusCfg:
	return cfg if isinstance(cfg, StimulusCfg) else StimulusCfg.from_dict(cfg)


PRESETS = {
	"clean": {},
	"noisy letter": {"noise.form_contrast": 0.6},
	"motion only": {"noise.form_contrast": 0.0, "objects.0.motion.speed": 2.0},
	"motion only, two objects": {
		"noise.form_contrast": 0.0,
		"objects": [
			asdict(ObjectCfg(shape=ShapeCfg(chars="Q", size=128.0),
				motion=MotionCfg(start_x=80 / 256, start_y=84 / 256))),
			asdict(ObjectCfg(shape=ShapeCfg(chars="A", size=64.0),
				motion=MotionCfg(start_x=56 / 256, start_y=204 / 256))),
		],
		"shared.overrides.motion.speed": 2.0,
	},
	"matched background": {"noise.form_contrast": 0.0, "noise.bg_motion": "matched", "noise.bg_coherence": None, "objects.0.motion.speed": 2.0},
	"pure noise": {"noise.form_contrast": 0.0, "noise.coherence": 0.0, "noise.bg_coherence": 0.0},
	"pursuit (fixate the letter)": {"view.fixate": "object", "noise.form_contrast": 0.0, "noise.bg_motion": "static", "objects.0.motion.speed": 2.0},
	# The held letter's texture drifts as fast as the background streams, so no pixel stands still (cf. SpookyBench).
	"pursuit + drifting texture": {
		"view.fixate": "object",
		"noise.form_contrast": 0.0,
		"noise.bg_motion": "static",
		"objects.0.motion.speed": 2.0,
		"noise.texture_speed": 2.0,
	},
	"kinematogram (dots)": {
		"objects.0.motion.speed": 2.0,
		"texture.carrier": "dots",
		"noise.form_contrast": 0.0,
		"noise.coherence_mode": "lifetime",
		"noise.coherence": 0.9,
		"noise.bg_motion": "static",
	},
	"window over flowing noise": {
		"objects.0.motion.speed": 0.0,
		"objects.0.motion.start_x": 0.5,
		"objects.0.motion.start_y": 0.5,
		"noise.form_contrast": 0.0,
		"noise.texture_frame": "world",
		"noise.texture_speed": 2.0,
		"noise.texture_direction": 270.0,
		"noise.bg_motion": "drift",
		"noise.bg_speed": 2.0,
		"noise.bg_direction": 90.0,
	},
	"atom letters": {"objects.0.shape.kind": "atom", "objects.0.shape.chars": "AEFHIKLMNTVWXYZ"},
	"bouncing bar": {
		"objects.0.motion.speed": 2.0,
		"objects.0.motion.bounce": True,
		"objects.0.shape.kind": "bar",
		"objects.0.motion.align_heading": True,
		"objects.0.motion.angle": 90.0,
	},
	"spinning diamond": {"objects.0.shape.kind": "diamond", "objects.0.motion.spin": 3.0},
}


def preset(name: str) -> StimulusCfg:
	return StimulusCfg().replace(PRESETS[name])


def sweep(axes: dict) -> list[dict]:
	"""Cartesian product of {dotted path: [values]} as a list of override dicts."""
	keys = list(axes)
	return [dict(zip(keys, combo)) for combo in itertools.product(*(axes[k] for k in keys))]


def benchmark_conditions(
		form_levels=(1.0, 0.8, 0.6, 0.4, 0.2, 0.0),
		coherence_levels=(1.0, 0.75, 0.5, 0.25, 0.0),
) -> list[dict]:
	"""The two-stage path: form contrast 1 -> 0 at full coherence, then coherence 1 -> 0 at zero form contrast."""
	stage_a = [{"noise.form_contrast": a, "noise.coherence": 1.0, "noise.bg_coherence": 1.0} for a in form_levels]
	stage_b = [{"noise.form_contrast": 0.0, "noise.coherence": c, "noise.bg_coherence": c} for c in coherence_levels]
	return stage_a + [c for c in stage_b if c not in stage_a]


def schema() -> dict:
	"""Field descriptions for building UIs."""
	def group(cls, name, label):
		return {"name": name, "label": label, "fields": [_field_schema(f) for f in fields(cls) if f.name != "overrides"]}

	return {
		"groups": [
			group(VideoCfg, "video", "Video"),
			group(TextureCfg, "texture", "Texture"),
			group(NoiseCfg, "noise", "Signal & noise"),
			group(ViewCfg, "view", "View"),
			group(SharedObjectCfg, "shared", "Shared object settings"),
		],
		"object": [group(ShapeCfg, "shape", "Shape"), group(MotionCfg, "motion", "Motion")],
		"object_fields": sorted(object_fields()),
		"common_appearance_fields": sorted(common_appearance_fields()),
	}


def _field_schema(f) -> dict:
	default = f.default if f.default is not MISSING else f.default_factory()
	if "choices" in f.metadata:
		kind = "choice"
	elif f.type is bool:
		kind = "bool"
	elif f.type is int:
		kind = "int"
	elif f.type is str:
		kind = "text"
	else:
		kind = "number"
	return {"name": f.name, "type": kind, "default": default, **f.metadata}
