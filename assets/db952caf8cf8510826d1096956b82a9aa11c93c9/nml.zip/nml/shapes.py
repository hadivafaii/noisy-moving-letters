"""Shapes as signed distance functions (SDFs) in object coordinates.

Units are pixels at scale 1, x points right, y points down, and negative distances are
inside. Every shape has a `radius` bounding it around the origin. Shapes compose with
`Union`, `Transform` and `Outline`; oriented `Segment`s are the atoms that `atom_letter`
builds letters from.
"""

from functools import cached_property

import numpy as np
from scipy import ndimage
from scipy.spatial import ConvexHull

from nml.glyphs import _CAP_HEIGHT, glyph_sdf, resolve_chars
from nml.limits import check_allocation


def _contour_hull(values, xs, ys):
	"""Convex hull of interpolated zero crossings, in shape coordinates."""
	points = []
	for axis in (0, 1):
		a, b = (values[:-1], values[1:]) if axis == 0 else (values[:, :-1], values[:, 1:])
		i, j = np.nonzero((a < 0) != (b < 0))
		fraction = a[i, j] / (a[i, j] - b[i, j])
		x = xs[j] + (fraction * (xs[j + 1] - xs[j]) if axis == 1 else 0)
		y = ys[i] + (fraction * (ys[i + 1] - ys[i]) if axis == 0 else 0)
		points.append(np.column_stack([x, y]))
	points = np.unique(np.concatenate(points), axis=0)
	if len(points) < 3:
		return points if len(points) else np.zeros((1, 2))
	return points[ConvexHull(points).vertices]


class Shape:
	radius = 0.0

	def sdf(self, x, y):
		raise NotImplementedError

	@cached_property
	def _hull(self):
		# Fallback for custom SDFs; built-in primitives have exact support functions.
		grid = np.linspace(-self.radius - 0.25, self.radius + 0.25, max(3, int(np.ceil(8 * self.radius)) + 3))
		x, y = np.meshgrid(grid, grid)
		return _contour_hull(self.sdf(x, y), grid, grid)

	def support(self, directions):
		"""Farthest projection of the visible shape along each (dx, dy)."""
		return np.max(np.sum(np.asarray(directions)[..., None, :] * self._hull, axis=-1), axis=-1)

	def bounds(self, angle=0.0, scale=1.0):
		"""Left, right, top, bottom offsets at the rendered orientation and scale."""
		c, s = np.cos(angle), np.sin(angle)
		d = self.support(np.array([[-c, s], [c, -s], [-s, -c], [s, c]]))
		return d * np.array([-scale, scale, -scale, scale])

	def area(self, step=0.25) -> float:
		check_allocation((2 * self.radius / step + 2) ** 2 * 4, "Shape area sampling")
		grid = np.arange(-self.radius, self.radius + step, step)
		x, y = np.meshgrid(grid, grid)
		return float((self.sdf(x, y) < 0).sum()) * step ** 2

	def extent(self, angle=0.0, scale=1.0, step=0.25) -> tuple[float, float]:
		"""Width and height (px) of the shape's bounding box on screen at this orientation (rad, clockwise) and scale."""
		left, right, top, bottom = self.bounds(angle, scale)
		return float(right - left), float(bottom - top)


def _box(x, y, hx, hy):
	dx = np.abs(x) - hx
	dy = np.abs(y) - hy
	return np.hypot(np.maximum(dx, 0), np.maximum(dy, 0)) + np.minimum(np.maximum(dx, dy), 0)


def _rotate(x, y, angle):
	c, s = np.cos(angle), np.sin(angle)
	return c * x - s * y, s * x + c * y


class Segment(Shape):
	"""A stroke from p0 to p1 with the given thickness; round caps make a capsule, flat caps a rectangle."""

	def __init__(self, p0, p1, thickness, cap="round"):
		self.p0 = np.asarray(p0, dtype=float)
		self.p1 = np.asarray(p1, dtype=float)
		self.half = thickness / 2
		self.cap = cap
		self.radius = max(np.hypot(*self.p0), np.hypot(*self.p1)) + self.half * np.sqrt(2)

	def support(self, directions):
		d = np.asarray(directions)
		length = np.linalg.norm(self.p1 - self.p0)
		if self.cap == "round" or length == 0:
			return np.maximum(d @ self.p0, d @ self.p1) + self.half * np.linalg.norm(d, axis=-1)
		ux, uy = (self.p1 - self.p0) / length
		return d @ ((self.p0 + self.p1) / 2) + np.abs(d @ [ux, uy]) * length / 2 + np.abs(d @ [-uy, ux]) * self.half

	def sdf(self, x, y):
		(ax, ay), (ex, ey) = self.p0, self.p1 - self.p0
		length2 = ex * ex + ey * ey
		if length2 == 0:
			return np.hypot(x - ax, y - ay) - self.half
		if self.cap == "round":
			h = np.clip(((x - ax) * ex + (y - ay) * ey) / length2, 0, 1)
			return np.hypot(x - ax - h * ex, y - ay - h * ey) - self.half
		length = np.sqrt(length2)
		ux, uy = ex / length, ey / length
		cx, cy = ax + ex / 2, ay + ey / 2
		along = (x - cx) * ux + (y - cy) * uy
		across = -(x - cx) * uy + (y - cy) * ux
		return _box(along, across, length / 2, self.half)


class Box(Shape):
	def __init__(self, width, height, angle=0.0):
		self.hx, self.hy, self.angle = width / 2, height / 2, angle
		self.radius = np.hypot(self.hx, self.hy)

	def support(self, directions):
		d = np.asarray(directions)
		x, y = _rotate(d[..., 0], d[..., 1], -self.angle)
		return np.abs(x) * self.hx + np.abs(y) * self.hy

	def sdf(self, x, y):
		x, y = _rotate(x, y, -self.angle)
		return _box(x, y, self.hx, self.hy)


class Circle(Shape):
	def __init__(self, r):
		self.r = self.radius = r

	def support(self, directions):
		return self.r * np.linalg.norm(directions, axis=-1)

	def sdf(self, x, y):
		return np.hypot(x, y) - self.r


class Ellipse(Shape):
	"""Approximate distance (exact zero set), after Inigo Quilez."""

	def __init__(self, a, b):
		self.a, self.b = a, b
		self.radius = max(a, b)

	def support(self, directions):
		d = np.asarray(directions)
		return np.hypot(self.a * d[..., 0], self.b * d[..., 1])

	def sdf(self, x, y):
		k0 = np.hypot(x / self.a, y / self.b)
		k1 = np.hypot(x / self.a ** 2, y / self.b ** 2)
		return np.where(k1 > 0, k0 * (k0 - 1) / np.maximum(k1, 1e-12), -min(self.a, self.b))


class Polygon(Shape):
	"""Exact distance to a simple polygon, after Inigo Quilez."""

	def __init__(self, vertices):
		self.v = np.asarray(vertices, dtype=float)
		self.radius = float(np.hypot(self.v[:, 0], self.v[:, 1]).max())

	def support(self, directions):
		return np.max(np.sum(np.asarray(directions)[..., None, :] * self.v, axis=-1), axis=-1)

	def sdf(self, x, y):
		v = self.v
		d = (x - v[0, 0]) ** 2 + (y - v[0, 1]) ** 2
		sign = np.ones_like(d)
		for i in range(len(v)):
			(vx, vy), (wx, wy) = v[i], v[i - 1]
			ex, ey = wx - vx, wy - vy
			px, py = x - vx, y - vy
			h = np.clip((px * ex + py * ey) / (ex * ex + ey * ey), 0, 1)
			d = np.minimum(d, (px - h * ex) ** 2 + (py - h * ey) ** 2)
			c1, c2, c3 = y >= vy, y < wy, ex * py > ey * px
			flip = (c1 & c2 & c3) | (~c1 & ~c2 & ~c3)
			sign = np.where(flip, -sign, sign)
		return sign * np.sqrt(d)


class Glyph(Shape):
	"""A font character, centred on its bounding box; `size` is the cap height in px."""

	def __init__(self, char, size, font="DejaVu Sans:bold"):
		self.char, self.size = char, size
		self.map, self.cx, self.cy, r = glyph_sdf(char, font)
		self.k = _CAP_HEIGHT / size
		self.radius = r / self.k

	def contour(self, level=0.0):
		# The glyph renderer uses bilinear interpolation. Subdivide its native grid
		# for subpixel wall contact even at rotated, curved edges.
		h, w = self.map.shape
		ys, xs = np.arange(4 * (h - 1) + 1) / 4, np.arange(4 * (w - 1) + 1) / 4
		y, x = np.meshgrid(ys, xs, indexing="ij")
		values = ndimage.map_coordinates(self.map, [y, x], order=1) - level * self.k
		return _contour_hull(values, (xs - self.cx) / self.k, (ys - self.cy) / self.k)

	@cached_property
	def _hull(self):
		return self.contour()

	def sdf(self, x, y):
		x, y = np.broadcast_arrays(np.asarray(x, dtype=float), np.asarray(y, dtype=float))
		coords = np.stack([self.cy + y.ravel() * self.k, self.cx + x.ravel() * self.k])
		d = ndimage.map_coordinates(self.map, coords, order=1, mode="constant", cval=1e4)
		return d.reshape(x.shape) / self.k


class Union(Shape):
	def __init__(self, *shapes):
		self.shapes = shapes
		self.radius = max(s.radius for s in shapes)

	def support(self, directions):
		return np.max([s.support(directions) for s in self.shapes], axis=0)

	def sdf(self, x, y):
		return np.minimum.reduce([s.sdf(x, y) for s in self.shapes])


class Transform(Shape):
	def __init__(self, shape, angle=0.0, offset=(0.0, 0.0), scale=1.0):
		self.shape, self.angle, self.offset, self.scale = shape, angle, offset, scale
		self.radius = shape.radius * scale + np.hypot(*offset)

	def support(self, directions):
		d = np.asarray(directions)
		x, y = _rotate(d[..., 0], d[..., 1], -self.angle)
		return self.scale * self.shape.support(np.stack([x, y], axis=-1)) + d @ self.offset

	def sdf(self, x, y):
		x, y = _rotate(x - self.offset[0], y - self.offset[1], -self.angle)
		return self.shape.sdf(x / self.scale, y / self.scale) * self.scale


class Outline(Shape):
	def __init__(self, shape, width):
		self.shape, self.half = shape, width / 2
		self.radius = shape.radius + self.half

	@cached_property
	def _hull(self):
		if isinstance(self.shape, Glyph):
			return self.shape.contour(self.half)
		return super()._hull

	def support(self, directions):
		# Glyph interpolation and the approximate ellipse SDF need their actual
		# outer contour; exact distance fields simply expand by half the stroke.
		if isinstance(self.shape, (Glyph, Ellipse)):
			return super().support(directions)
		return self.shape.support(directions) + self.half * np.linalg.norm(directions, axis=-1)

	def sdf(self, x, y):
		return np.abs(self.shape.sdf(x, y)) - self.half


# Straight-stroke letters on a unit-height box (y from -0.5 at the top to 0.5 at the bottom).
_L, _R, _T, _B = -0.35, 0.35, -0.5, 0.5
ATOM_STROKES = {
	"A": [(_L, _B, 0, _T), (0, _T, _R, _B), (-0.21, 0.1, 0.21, 0.1)],
	"E": [(_L, _T, _L, _B), (_L, _T, _R, _T), (_L, 0, 0.25, 0), (_L, _B, _R, _B)],
	"F": [(_L, _T, _L, _B), (_L, _T, _R, _T), (_L, 0, 0.25, 0)],
	"H": [(_L, _T, _L, _B), (_R, _T, _R, _B), (_L, 0, _R, 0)],
	"I": [(0, _T, 0, _B), (-0.2, _T, 0.2, _T), (-0.2, _B, 0.2, _B)],
	"K": [(_L, _T, _L, _B), (_L, 0.05, _R, _T), (-0.12, -0.08, _R, _B)],
	"L": [(_L, _T, _L, _B), (_L, _B, _R, _B)],
	"M": [(-0.42, _B, -0.42, _T), (-0.42, _T, 0, 0.15), (0, 0.15, 0.42, _T), (0.42, _T, 0.42, _B)],
	"N": [(_L, _B, _L, _T), (_L, _T, _R, _B), (_R, _B, _R, _T)],
	"T": [(_L, _T, _R, _T), (0, _T, 0, _B)],
	"V": [(_L, _T, 0, _B), (0, _B, _R, _T)],
	"W": [(-0.48, _T, -0.24, _B), (-0.24, _B, 0, -0.1), (0, -0.1, 0.24, _B), (0.24, _B, 0.48, _T)],
	"X": [(_L, _T, _R, _B), (_R, _T, _L, _B)],
	"Y": [(_L, _T, 0, 0), (_R, _T, 0, 0), (0, 0, 0, _B)],
	"Z": [(_L, _T, _R, _T), (_R, _T, _L, _B), (_L, _B, _R, _B)],
	"1": [(0, _T, 0, _B), (-0.2, -0.3, 0, _T)],
	"4": [(0.15, _T, _L, 0.15), (_L, 0.15, _R, 0.15), (0.15, _T, 0.15, _B)],
	"7": [(_L, _T, _R, _T), (_R, _T, -0.1, _B)],
}


def atom_letter(char, size, thickness) -> Shape:
	"""A letter composed of round-capped segment atoms; `size` is its height in px."""
	if char not in ATOM_STROKES:
		raise ValueError(f"No atom letter for {char!r}; available: {''.join(ATOM_STROKES)}")
	return Union(*[
		Segment((x0 * size, y0 * size), (x1 * size, y1 * size), thickness)
		for x0, y0, x1, y1 in ATOM_STROKES[char]
	])


def regular_polygon(n, circumradius, angle=-np.pi / 2) -> Polygon:
	theta = angle + 2 * np.pi * np.arange(n) / n
	return Polygon(np.stack([np.cos(theta), np.sin(theta)], axis=1) * circumradius)


def shape_chars(kind: str, spec: str) -> str:
	"""Characters a glyph or atom shape can draw from."""
	chars = resolve_chars(spec)
	if kind == "atom":
		chars = "".join(c for c in chars if c in ATOM_STROKES) or chars
	return chars


def make_shape(kind, char="A", size=32.0, thickness=5.0, length=28.0, aspect=1.5, sides=5, outline=0.0, font="DejaVu Sans:bold") -> Shape:
	if kind == "glyph":
		shape = Glyph(char, size, font)
	elif kind == "atom":
		shape = atom_letter(char, size, thickness)
	elif kind == "bar":
		shape = Segment((-length / 2, 0), (length / 2, 0), thickness, cap="flat")
	elif kind == "square":
		shape = Box(size, size)
	elif kind == "diamond":
		shape = Box(size, size, angle=np.pi / 4)
	elif kind == "rect":
		shape = Box(size * aspect, size)
	elif kind == "triangle":
		shape = regular_polygon(3, size / 1.5)
	elif kind == "ngon":
		shape = regular_polygon(int(sides), size / 2)
	elif kind == "circle":
		shape = Circle(size / 2)
	elif kind == "ellipse":
		shape = Ellipse(size * aspect / 2, size / 2)
	else:
		raise ValueError(f"Unknown shape kind {kind!r}")
	return Outline(shape, outline) if outline > 0 else shape
