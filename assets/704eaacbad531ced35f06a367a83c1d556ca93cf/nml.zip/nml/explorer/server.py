"""Small local HTTP service: the browser sends configs, the real generator renders them."""

import base64
import io
import json
import logging
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from typing import NamedTuple

import numpy as np
from PIL import Image, ImageDraw, ImageFont

from nml.config import PRESETS, StimulusCfg, preset, schema
from nml.diagnostics import leakage
from nml.glyphs import available_fonts, find_font
from nml.render import generate, resolve
from nml.trajectory import travelled
from nml.viz import MP4_MAX_LONG_EDGE, MP4_MAX_SHORT_EDGE, mp4_bytes, mp4_scale, save_gif, scaled_size, tile, to_uint8


DEFAULT_PREVIEW_BUDGET = 16_777_216  # width × height × frames × object count
EXPORT_GAP = 12
EXPORT_TITLE_HEIGHT = 28
EXPORT_BASE_SIZE = 512
EXPORT_RESOLUTION_SCALES = (1, 2, 4, 8)

STATIC = Path(__file__).parent / "static"
ASSETS = {
	"/": ("index.html", "text/html"),
	"/app.js": ("app.js", "text/javascript"),
	"/live.js": ("live.js", "text/javascript"),
	"/hosting.js": ("hosting.js", "text/javascript"),
	"/app.css": ("app.css", "text/css"),
	"/favicon.svg": ("favicon.svg", "image/svg+xml"),
}


def _b64(array) -> str:
	return base64.b64encode(np.ascontiguousarray(array).tobytes()).decode()


def _summary(obj, frames) -> dict:
	"""What a seed drew for one object: its label, bounding box (px) in the first frame, mean speed along its path
	(px/frame) and initial heading in the world (deg, 0 = right, 90 = down)."""
	_, _, angle, scale = obj["poses"][0]
	width, height = obj["shape"].extent(angle, scale)
	step = np.diff(obj["poses"][:, :2], axis=0)
	moving = np.nonzero(np.hypot(step[:, 0], step[:, 1]) > 1e-6)[0]
	heading = float(np.degrees(np.arctan2(step[moving[0], 1], step[moving[0], 0])) % 360) if len(moving) else None
	speed = np.abs(np.diff(travelled(obj["params"], frames))).mean() if len(moving) else 0.0
	return {"label": obj["label"], "width": width, "height": height, "speed": round(float(speed), 3), "heading": heading}


def validate_preview_budget(value):
	if not isinstance(value, int) or isinstance(value, bool) or not 1 <= value <= 2 ** 53 - 1:
		raise ValueError("preview_budget must be a positive safe integer")
	return value


def validate_seed(value):
	if not isinstance(value, int) or isinstance(value, bool) or not 0 <= value <= 4294967295:
		raise ValueError("seed must be an integer from 0 to 4294967295")
	return value


class PreviewLimitExceeded(ValueError):
	def __init__(self, cfg, budget):
		per_frame = cfg.video.width * cfg.video.height * len(cfg.objects)
		self.requested = per_frame * cfg.video.frames
		self.budget = budget
		self.max_frames = budget // per_frame
		super().__init__(
			f"This clip needs {self.requested:,} pixel-frames; the preview limit is {budget:,}. "
			f"At {cfg.video.width} × {cfg.video.height} with {len(cfg.objects)} object(s), "
			f"the limit allows {self.max_frames} frames. Increase the preview limit to continue."
		)


class ExportLimitExceeded(PreviewLimitExceeded):
	def __init__(self, requested, budget, per_frame):
		self.requested, self.budget = requested, budget
		self.max_frames = budget // per_frame
		ValueError.__init__(self,
			f"This download needs {requested:,} pixel-frames; the preview limit is {budget:,}. "
			"Increase the preview limit to export at the selected resolution.")


def export_scale(body, width, height):
	"""Resolution multiplier relative to the existing automatic export size."""
	factor = body.get("resolution_scale", 1)
	if not isinstance(factor, int) or isinstance(factor, bool) or factor not in EXPORT_RESOLUTION_SCALES:
		raise ValueError("resolution_scale must be 1, 2, 4, or 8")
	scale = max(1, EXPORT_BASE_SIZE // max(width, height)) * factor
	return scale if body.get("format") == "gif" else mp4_scale(width, height, scale)


def check_export_budget(body, cfgs, width, height, length, budget):
	"""Check both rendering and the encoded dimensions before allocating frames."""
	native_pixels = width * height
	scale = export_scale(body, width, height)
	width, height = scaled_size(width, height, scale)
	if body.get("format") != "gif":
		width += width % 2
		height += height % 2
	costs = [cfg.video.width * cfg.video.height * len(cfg.objects) for cfg in cfgs]
	requested = max(native_pixels * length, width * height * length, *(cost * cfg.video.frames for cost, cfg in zip(costs, cfgs)))
	if requested > budget:
		raise ExportLimitExceeded(requested, budget, max(native_pixels, width * height, *costs))


def explorer_config(config: dict, preview_budget=DEFAULT_PREVIEW_BUDGET) -> StimulusCfg:
	cfg = StimulusCfg.from_dict(config)
	if not 1 <= len(cfg.objects) <= 8:
		raise ValueError("The explorer supports 1–8 objects")
	# Validation/imports do not allocate a preview. Rendering and exporting always check a budget.
	if preview_budget is not None:
		validate_preview_budget(preview_budget)
		if cfg.video.width * cfg.video.height * cfg.video.frames * len(cfg.objects) > preview_budget:
			raise PreviewLimitExceeded(cfg, preview_budget)
	return cfg


def render_payload(config: dict, seed: int, preview_budget=DEFAULT_PREVIEW_BUDGET) -> dict:
	cfg = explorer_config(config, preview_budget)

	t0 = time.perf_counter()
	objects = resolve(cfg, seed)
	sample = generate(cfg, seed=seed, objects=objects)
	ms = (time.perf_counter() - t0) * 1000
	T, H, W = sample.frames.shape
	return {
		"T": T, "H": H, "W": W, "ms": round(ms, 1),
		"frames": _b64(to_uint8(sample.frames)),
		"mask": _b64(np.packbits(sample.masks.any(axis=1))),
		"labels": sample.labels,
		"objects": [_summary(o, T) for o in objects],
	}


def combined_export(body, budget):
	"""Export the ordered preview grid, preserving each scene's pixels and seed."""
	scenes = body.get("scenes")
	if not isinstance(scenes, list) or not scenes or any(not isinstance(scene, dict) for scene in scenes):
		raise ValueError("scenes must be a nonempty list of preview settings")
	columns = body.get("columns", 2)
	if not isinstance(columns, int) or isinstance(columns, bool) or columns not in (1, 2):
		raise ValueError("columns must be 1 or 2")
	fps = body.get("fps")
	if not isinstance(fps, int) or isinstance(fps, bool) or fps < 1:
		raise ValueError("fps must be a positive integer")
	# Validate the complete set and its output size before allocating any stimulus.
	cfgs = [explorer_config(scene["config"], preview_budget=None) for scene in scenes]
	seeds = [validate_seed(scene.get("seed", 0)) for scene in scenes]
	names = [scene.get("title", f"Preview {i+1}") for i, scene in enumerate(scenes)]
	if any(not isinstance(name, str) or not name.strip() for name in names):
		raise ValueError("Preview titles must be nonempty text")
	columns = min(columns, len(scenes))
	rows = (len(scenes) + columns - 1) // columns
	cell_w, cell_h = max(cfg.video.width for cfg in cfgs), max(cfg.video.height for cfg in cfgs)
	width = columns * cell_w + (columns - 1) * EXPORT_GAP
	height = rows * (cell_h + EXPORT_TITLE_HEIGHT) + (rows - 1) * EXPORT_GAP
	length = max(cfg.video.frames for cfg in cfgs)
	check_export_budget(body, cfgs, width, height, length, budget)

	# Rasterize titles once at the final resolution; encoders paste them after
	# scaling each frame so text stays smooth without blurring stimulus pixels.
	scale = export_scale(body, width, height)
	font = ImageFont.truetype(find_font("DejaVu Sans:normal"), max(1, int(14 * scale)))
	overlays = []
	for i, name in enumerate(names):
		x = (i % columns) * (cell_w + EXPORT_GAP)
		y = (i // columns) * (cell_h + EXPORT_TITLE_HEIGHT + EXPORT_GAP)
		heading = Image.new("L", scaled_size(cell_w, EXPORT_TITLE_HEIGHT, scale), 238)
		draw = ImageDraw.Draw(heading)
		label = " ".join(name.split())[:60]
		if draw.textlength(label, font=font) > heading.width:
			while label and draw.textlength(label + "…", font=font) > heading.width:
				label = label[:-1]
			label = label + "…" if label else ""
		draw.text((0, int(5 * scale)), label, fill=48, font=font)
		overlays.append(((int(x * scale), int(y * scale)), heading))
	frames = np.full((length, height, width), 238, dtype=np.uint8)
	# Render sequentially into a byte canvas instead of retaining every float video.
	for i, (cfg, seed) in enumerate(zip(cfgs, seeds)):
		video = to_uint8(generate(cfg, seed=seed).frames)
		x = (i % columns) * (cell_w + EXPORT_GAP) + (cell_w - cfg.video.width) // 2
		y = (i // columns) * (cell_h + EXPORT_TITLE_HEIGHT + EXPORT_GAP) + EXPORT_TITLE_HEIGHT + (cell_h - cfg.video.height) // 2
		for t in range(length):
			frames[t, y:y + cfg.video.height, x:x + cfg.video.width] = video[t % len(video)]
	return frames, fps, overlays


class Reply(NamedTuple):
	body: object
	status: int = 200
	content_type: str = "application/json"
	filename: str | None = None


def schema_payload(preview_budget=DEFAULT_PREVIEW_BUDGET):
	return {"schema": schema(),
		"default": preset("motion only, two objects").to_dict(),
		"preset_default": StimulusCfg().to_dict(), "presets": PRESETS,
		"preview_budget": preview_budget, "fonts": available_fonts(),
		"export_options": {"gap": EXPORT_GAP, "title_height": EXPORT_TITLE_HEIGHT,
			"base_size": EXPORT_BASE_SIZE, "mp4_bounds": [MP4_MAX_LONG_EDGE, MP4_MAX_SHORT_EDGE]}}


def export_frames(body, budget):
	"""Prepare the same pixels and labels for native and browser encoders."""
	overlays = ()
	if "scenes" in body:
		frames, fps, overlays = combined_export(body, budget)
		filename = "all-previews"
	else:
		seed = validate_seed(body.get("seed", 0))
		cfgs = [explorer_config(c, preview_budget=None) for c in body.get("configs") or [body["config"]]]
		width = sum(cfg.video.width for cfg in cfgs) + 2 * (len(cfgs) - 1)
		height = max(cfg.video.height for cfg in cfgs)
		length = max(cfg.video.frames for cfg in cfgs)
		check_export_budget(body, cfgs, width, height, length, budget)
		videos = [generate(cfg, seed=seed).frames for cfg in cfgs]
		frames = videos[0] if len(videos) == 1 else tile(videos)
		fps = cfgs[0].video.fps
		filename = "stimulus"
	return frames, fps, overlays, filename


def api_request(path, body, preview_budget=DEFAULT_PREVIEW_BUDGET):
	"""Shared API implementation used by both the local and hosted explorer."""
	if not isinstance(body, dict):
		raise ValueError("Request must be a JSON object")
	seed = validate_seed(body.get("seed", 0))
	budget = validate_preview_budget(body.get("preview_budget", preview_budget))
	if path == "/api/validate":
		return Reply({"config": explorer_config(body["config"], preview_budget=None).to_dict(), "seed": seed})
	if path == "/api/render":
		return Reply(render_payload(body["config"], seed, preview_budget=budget))
	if path == "/api/leakage":
		report = leakage(StimulusCfg.from_dict(body["config"]), seed=seed)
		return Reply({k: (None if np.isnan(v) else round(v, 3)) for k, v in report.items()})
	if path == "/api/export":
		frames, fps, overlays, filename = export_frames(body, budget)
		scale = export_scale(body, frames.shape[2], frames.shape[1])
		if body.get("format") == "gif":
			buf = io.BytesIO()
			save_gif(frames, buf, fps=fps, scale=scale, overlays=overlays)
			return Reply(buf.getvalue(), content_type="image/gif", filename=filename + ".gif")
		return Reply(mp4_bytes(frames, fps=fps, scale=scale, overlays=overlays), content_type="video/mp4", filename=filename + ".mp4")
	return Reply({"error": "Not found."}, status=404)


def make_server(host="127.0.0.1", port=8770, preview_budget=DEFAULT_PREVIEW_BUDGET):
	validate_preview_budget(preview_budget)
	for name in PRESETS:
		preset(name)  # a preset that no longer matches the config fails here, not in the browser

	class Handler(BaseHTTPRequestHandler):
		def log_message(self, format, *args):
			logging.getLogger(__name__).info(format, *args)

		def valid_host(self):
			request_host = urlsplit("//" + self.headers.get("Host", "")).hostname
			return host == "0.0.0.0" or request_host in {host, "localhost", "127.0.0.1", "::1"}

		def send(self, body, status=200, content_type="application/json", filename=None):
			if content_type == "application/json":
				body = json.dumps(body, allow_nan=False).encode()
			self.send_response(status)
			self.send_header("Content-Type", content_type)
			self.send_header("Content-Length", str(len(body)))
			self.send_header("Cache-Control", "no-store")
			self.send_header("X-Content-Type-Options", "nosniff")
			if filename:
				self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
			self.end_headers()
			try:
				self.wfile.write(body)
			except (BrokenPipeError, ConnectionResetError):
				pass

		def do_GET(self):
			if not self.valid_host():
				return self.send({"error": "Unrecognized host."}, status=403)
			path = urlsplit(self.path).path
			if path in ASSETS:
				name, kind = ASSETS[path]
				return self.send((STATIC / name).read_bytes(), content_type=kind + "; charset=utf-8")
			if path == "/api/schema":
				return self.send(schema_payload(preview_budget))
			self.send({"error": "Not found."}, status=404)

		def do_POST(self):
			origin = self.headers.get("Origin")
			if not self.valid_host() or (origin and urlsplit(origin).netloc != self.headers.get("Host")):
				return self.send({"error": "Cross-origin request refused."}, status=403)
			try:
				length = int(self.headers.get("Content-Length", 0))
				if not 0 <= length <= 1_048_576:
					raise ValueError("Request body is too large")
				body = json.loads(self.rfile.read(length) or b"{}")
				if not isinstance(body, dict):
					raise ValueError("Request must be a JSON object")
				path = urlsplit(self.path).path
				return self.send(*api_request(path, body, preview_budget))
			except PreviewLimitExceeded as exc:
				return self.send({
					"error": str(exc), "code": "preview_limit", "requested": exc.requested,
					"preview_budget": exc.budget, "max_frames": exc.max_frames,
				}, status=409)
			except (KeyError, TypeError, ValueError) as exc:
				return self.send({"error": f"{type(exc).__name__}: {exc}"}, status=400)
			except Exception as exc:
				logging.getLogger(__name__).exception("Request to %s failed", self.path)
				return self.send({"error": f"{type(exc).__name__}: {exc}"}, status=500)

	return ThreadingHTTPServer((host, port), Handler)
